import axiosInstance from './axiosInstance';

export const bookingApi = {
  create: async (bookingData) => {
    const response = await axiosInstance.post('/bookings', bookingData);
    return response.data;
  },

  getMyBookings: async () => {
    const response = await axiosInstance.get('/bookings/my-bookings');
    return response.data;
  },

  getHostReservations: async () => {
    const response = await axiosInstance.get('/bookings/host-reservations');
    return response.data;
  },

  getBookedDates: async (listingId) => {
    const response = await axiosInstance.get(`/bookings/listing/${listingId}/dates`);
    return response.data;
  },

  getById: async (id) => {
    const response = await axiosInstance.get(`/bookings/${id}`);
    return response.data;
  },

  cancel: async (id) => {
    const response = await axiosInstance.put(`/bookings/${id}/cancel`);
    return response.data;
  },
};
