import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import CategoriesBar from '../components/CategoriesBar';
import ListingCard from '../components/ListingCard';
import FilterModal from '../components/FilterModal';
import { listingApi } from '../api/listingApi';
import { Sparkles, RefreshCw, AlertCircle } from 'lucide-react';

const HomePage = ({ onOpenSearch }) => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [listings, setListings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isFilterModalOpen, setIsFilterModalOpen] = useState(false);

  // Read filter params from URL
  const activeCategory = searchParams.get('category') || 'All';
  const searchQuery = searchParams.get('search') || '';
  const minPrice = searchParams.get('minPrice') || '';
  const maxPrice = searchParams.get('maxPrice') || '';
  const propertyType = searchParams.get('propertyType') || '';
  const bedrooms = searchParams.get('bedrooms') || '';
  const bathrooms = searchParams.get('bathrooms') || '';
  const guests = searchParams.get('guests') || '';
  const sort = searchParams.get('sort') || '';
  const amenitiesParam = searchParams.get('amenities') || '';
  const amenities = amenitiesParam ? amenitiesParam.split(',') : [];

  // Count active filters (excluding category & default search)
  const activeFiltersCount = [
    minPrice,
    maxPrice,
    propertyType,
    bedrooms,
    bathrooms,
    guests,
    sort,
    amenities.length > 0,
  ].filter(Boolean).length;

  // Fetch listings whenever search params change
  useEffect(() => {
    const fetchListings = async () => {
      setLoading(true);
      setError(null);
      try {
        const params = {};
        if (activeCategory && activeCategory !== 'All') params.category = activeCategory;
        if (searchQuery) params.search = searchQuery;
        if (minPrice) params.minPrice = minPrice;
        if (maxPrice) params.maxPrice = maxPrice;
        if (propertyType) params.propertyType = propertyType;
        if (bedrooms) params.bedrooms = bedrooms;
        if (bathrooms) params.bathrooms = bathrooms;
        if (guests) params.guests = guests;
        if (sort) params.sort = sort;
        if (amenities.length > 0) params.amenities = amenities.join(',');

        const data = await listingApi.getAll(params);
        if (data.success) {
          setListings(data.listings || []);
        }
      } catch (err) {
        setError(err.message || 'Failed to load property listings');
      } finally {
        setLoading(false);
      }
    };

    fetchListings();
  }, [searchParams]);

  const handleSelectCategory = (categoryId) => {
    const newParams = new URLSearchParams(searchParams);
    if (categoryId === 'All') {
      newParams.delete('category');
    } else {
      newParams.set('category', categoryId);
    }
    setSearchParams(newParams);
  };

  const handleApplyFilters = (newFilters) => {
    const newParams = new URLSearchParams(searchParams);

    if (newFilters.minPrice) newParams.set('minPrice', newFilters.minPrice);
    else newParams.delete('minPrice');

    if (newFilters.maxPrice) newParams.set('maxPrice', newFilters.maxPrice);
    else newParams.delete('maxPrice');

    if (newFilters.propertyType) newParams.set('propertyType', newFilters.propertyType);
    else newParams.delete('propertyType');

    if (newFilters.bedrooms) newParams.set('bedrooms', newFilters.bedrooms);
    else newParams.delete('bedrooms');

    if (newFilters.bathrooms) newParams.set('bathrooms', newFilters.bathrooms);
    else newParams.delete('bathrooms');

    if (newFilters.sort) newParams.set('sort', newFilters.sort);
    else newParams.delete('sort');

    if (newFilters.amenities && newFilters.amenities.length > 0) {
      newParams.set('amenities', newFilters.amenities.join(','));
    } else {
      newParams.delete('amenities');
    }

    setSearchParams(newParams);
  };

  const handleClearAllFilters = () => {
    setSearchParams({});
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Category Icons Carousel */}
      <CategoriesBar
        activeCategory={activeCategory}
        onSelectCategory={handleSelectCategory}
        onOpenFilters={() => setIsFilterModalOpen(true)}
        activeFiltersCount={activeFiltersCount}
      />

      {/* Main Content Area */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 pb-16">
        
        {/* Active Search & Filter Tags */}
        {(searchQuery || activeFiltersCount > 0 || (activeCategory && activeCategory !== 'All')) && (
          <div className="flex flex-wrap items-center gap-2 mb-6 p-3 bg-gray-50 rounded-2xl border border-gray-200 text-xs">
            <span className="font-semibold text-gray-500">Active filters:</span>
            {searchQuery && (
              <span className="px-2.5 py-1 bg-white border border-gray-300 rounded-full font-medium text-gray-800">
                Location: "{searchQuery}"
              </span>
            )}
            {activeCategory && activeCategory !== 'All' && (
              <span className="px-2.5 py-1 bg-white border border-gray-300 rounded-full font-medium text-gray-800">
                Category: {activeCategory}
              </span>
            )}
            {minPrice && (
              <span className="px-2.5 py-1 bg-white border border-gray-300 rounded-full font-medium text-gray-800">
                Min: ${minPrice}
              </span>
            )}
            {maxPrice && (
              <span className="px-2.5 py-1 bg-white border border-gray-300 rounded-full font-medium text-gray-800">
                Max: ${maxPrice}
              </span>
            )}
            {propertyType && (
              <span className="px-2.5 py-1 bg-white border border-gray-300 rounded-full font-medium text-gray-800">
                Type: {propertyType}
              </span>
            )}
            {guests && (
              <span className="px-2.5 py-1 bg-white border border-gray-300 rounded-full font-medium text-gray-800">
                Guests: {guests}+
              </span>
            )}
            <button
              onClick={handleClearAllFilters}
              className="ml-auto text-airbnb font-bold hover:underline"
            >
              Reset all
            </button>
          </div>
        )}

        {/* Loading State Skeletons */}
        {loading && (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {Array.from({ length: 8 }).map((_, idx) => (
              <div key={idx} className="animate-pulse space-y-3">
                <div className="aspect-square bg-gray-200 rounded-2xl w-full"></div>
                <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                <div className="h-4 bg-gray-200 rounded w-1/3"></div>
              </div>
            ))}
          </div>
        )}

        {/* Error State */}
        {!loading && error && (
          <div className="p-8 text-center bg-rose-50 border border-rose-200 rounded-3xl max-w-lg mx-auto my-12">
            <AlertCircle className="w-12 h-12 text-rose-500 mx-auto mb-3" />
            <h3 className="text-lg font-bold text-gray-900 mb-1">Failed to load listings</h3>
            <p className="text-sm text-gray-600 mb-4">{error}</p>
            <button
              onClick={() => window.location.reload()}
              className="inline-flex items-center space-x-2 px-5 py-2.5 bg-gray-900 hover:bg-black text-white text-xs font-semibold rounded-xl"
            >
              <RefreshCw className="w-4 h-4" />
              <span>Retry</span>
            </button>
          </div>
        )}

        {/* Empty State */}
        {!loading && !error && listings.length === 0 && (
          <div className="text-center py-20 px-4 max-w-md mx-auto">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4 text-gray-400">
              <Sparkles className="w-8 h-8" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">No exact matches found</h3>
            <p className="text-sm text-gray-500 mb-6">
              Try changing or clearing some of your filters or searching for a different destination.
            </p>
            <button
              onClick={handleClearAllFilters}
              className="px-6 py-2.5 border border-gray-900 text-gray-900 font-semibold rounded-xl text-sm hover:bg-gray-50 transition"
            >
              Clear all filters
            </button>
          </div>
        )}

        {/* Listings Grid */}
        {!loading && !error && listings.length > 0 && (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-6 gap-y-10">
            {listings.map((listing) => (
              <ListingCard key={listing._id} listing={listing} />
            ))}
          </div>
        )}

      </main>

      {/* Filter Modal */}
      <FilterModal
        isOpen={isFilterModalOpen}
        onClose={() => setIsFilterModalOpen(false)}
        filters={{
          minPrice,
          maxPrice,
          propertyType,
          bedrooms,
          bathrooms,
          sort,
          amenities,
        }}
        onApplyFilters={handleApplyFilters}
        onClearFilters={handleClearAllFilters}
      />
    </div>
  );
};

export default HomePage;
