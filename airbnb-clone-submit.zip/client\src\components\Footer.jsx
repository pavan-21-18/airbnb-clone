import React from 'react';
import { Globe, Heart } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gray-100 border-t border-gray-200 mt-20 text-gray-700 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          <div>
            <h5 className="font-bold text-gray-900 mb-3 text-sm">Support</h5>
            <ul className="space-y-2">
              <li><a href="#help" className="hover:underline">Help Center</a></li>
              <li><a href="#aircover" className="hover:underline">AirCover Support</a></li>
              <li><a href="#anti-discrimination" className="hover:underline">Anti-discrimination</a></li>
              <li><a href="#disability" className="hover:underline">Disability support</a></li>
              <li><a href="#cancellation" className="hover:underline">Cancellation options</a></li>
            </ul>
          </div>

          <div>
            <h5 className="font-bold text-gray-900 mb-3 text-sm">Hosting</h5>
            <ul className="space-y-2">
              <li><a href="/create-listing" className="hover:underline">Airbnb your home</a></li>
              <li><a href="#aircover-hosts" className="hover:underline">AirCover for Hosts</a></li>
              <li><a href="#resources" className="hover:underline">Hosting resources</a></li>
              <li><a href="#community" className="hover:underline">Community forum</a></li>
              <li><a href="#hosting-responsibly" className="hover:underline">Hosting responsibly</a></li>
            </ul>
          </div>

          <div>
            <h5 className="font-bold text-gray-900 mb-3 text-sm">Airbnb Clone</h5>
            <ul className="space-y-2">
              <li><a href="#newsroom" className="hover:underline">Newsroom</a></li>
              <li><a href="#features" className="hover:underline">New features</a></li>
              <li><a href="#careers" className="hover:underline">Careers</a></li>
              <li><a href="#investors" className="hover:underline">Investors</a></li>
              <li><a href="#giftcards" className="hover:underline">Gift cards</a></li>
            </ul>
          </div>

          <div>
            <h5 className="font-bold text-gray-900 mb-3 text-sm">Tech Stack & Capstone</h5>
            <div className="space-y-2 text-gray-600">
              <p><strong className="text-gray-900">Module - 8 Capstone Project</strong></p>
              <p>MERN Stack Architecture:</p>
              <p className="flex flex-wrap gap-1 text-[11px] pt-1">
                <span className="bg-white px-2 py-0.5 rounded border border-gray-200">MongoDB</span>
                <span className="bg-white px-2 py-0.5 rounded border border-gray-200">Express.js</span>
                <span className="bg-white px-2 py-0.5 rounded border border-gray-200">React.js</span>
                <span className="bg-white px-2 py-0.5 rounded border border-gray-200">Node.js</span>
                <span className="bg-white px-2 py-0.5 rounded border border-gray-200">Tailwind CSS</span>
                <span className="bg-white px-2 py-0.5 rounded border border-gray-200">JWT Auth</span>
                <span className="bg-white px-2 py-0.5 rounded border border-gray-200">Multer</span>
              </p>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-200 pt-6 flex flex-col sm:flex-row items-center justify-between text-gray-500 gap-4">
          <div className="flex items-center space-x-2">
            <span>© 2026 Airbnb Clone, Inc.</span>
            <span>•</span>
            <a href="#privacy" className="hover:underline">Privacy</a>
            <span>•</span>
            <a href="#terms" className="hover:underline">Terms</a>
            <span>•</span>
            <a href="#sitemap" className="hover:underline">Sitemap</a>
          </div>

          <div className="flex items-center space-x-6 font-semibold text-gray-800">
            <div className="flex items-center space-x-1 cursor-pointer hover:underline">
              <Globe className="w-4 h-4" />
              <span>English (US)</span>
            </div>
            <div className="cursor-pointer hover:underline">
              <span>$ USD</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
