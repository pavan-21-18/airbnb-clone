import axiosInstance from './axiosInstance';

export const listingApi = {
  getAll: async (params = {}) => {
    const response = await axiosInstance.get('/listings', { params });
    return response.data;
  },

  getById: async (id) => {
    const response = await axiosInstance.get(`/listings/${id}`);
    return response.data;
  },

  create: async (listingData) => {
    const response = await axiosInstance.post('/listings', listingData);
    return response.data;
  },

  update: async (id, listingData) => {
    const response = await axiosInstance.put(`/listings/${id}`, listingData);
    return response.data;
  },

  delete: async (id) => {
    const response = await axiosInstance.delete(`/listings/${id}`);
    return response.data;
  },

  getMyListings: async () => {
    const response = await axiosInstance.get('/listings/host/my-listings');
    return response.data;
  },

  uploadImages: async (formData) => {
    const response = await axiosInstance.post('/listings/upload', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
    return response.data;
  },
};
