const mongoose = require('mongoose');

let mongodInstance = null;

const connectDB = async () => {
  const uri = process.env.MONGODB_URI || 'mongodb://localhost:27017/airbnb_clone';

  try {
    console.log(`Connecting to MongoDB at: ${uri}`);
    // Attempt standard connection with a 3s timeout
    await mongoose.connect(uri, {
      serverSelectionTimeoutMS: 3000,
    });
    console.log(`MongoDB Connected successfully: ${mongoose.connection.host}`);
  } catch (error) {
    console.warn(`Local MongoDB daemon not detected (${error.message}).`);
    console.log('Initiating MongoMemoryServer for standalone zero-configuration execution...');

    try {
      const { MongoMemoryServer } = require('mongodb-memory-server');
      mongodInstance = await MongoMemoryServer.create({
        instance: {
          dbName: 'airbnb_clone',
        },
        spawn: {
          timeout: 60000,
        },
      });
      const memUri = mongodInstance.getUri();
      await mongoose.connect(memUri);
      console.log(`MongoDB In-Memory Server connected successfully at: ${memUri}`);
    } catch (memError) {
      console.error(`Failed to start MongoMemoryServer: ${memError.message}`);
      process.exit(1);
    }
  }
};

module.exports = connectDB;
