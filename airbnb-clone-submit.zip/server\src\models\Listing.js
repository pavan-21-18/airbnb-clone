const mongoose = require('mongoose');

const listingSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: [true, 'Please provide a title for your listing'],
      trim: true,
      maxlength: [100, 'Title cannot exceed 100 characters'],
    },
    description: {
      type: String,
      required: [true, 'Please provide a description'],
      maxlength: [2000, 'Description cannot exceed 2000 characters'],
    },
    category: {
      type: String,
      required: [true, 'Please select a category'],
      enum: [
        'Beachfront',
        'Cabins',
        'Iconic Cities',
        'Lakefront',
        'Mansions',
        'Countryside',
        'Tiny Homes',
        'Trending',
        'Castles',
        'Camping',
        'Villas',
        'Mountains',
      ],
      default: 'Beachfront',
    },
    propertyType: {
      type: String,
      required: [true, 'Please select property type'],
      enum: ['Apartment', 'House', 'Villa', 'Cabin', 'Studio', 'Condo', 'Cottage'],
      default: 'Apartment',
    },
    roomType: {
      type: String,
      required: [true, 'Please select room type'],
      enum: ['Entire place', 'Private room', 'Shared room'],
      default: 'Entire place',
    },
    location: {
      address: { type: String, required: true },
      city: { type: String, required: true },
      state: { type: String, required: true },
      country: { type: String, required: true },
      zipCode: { type: String, default: '' },
      lat: { type: Number, default: 0 },
      lng: { type: Number, default: 0 },
    },
    pricePerNight: {
      type: Number,
      required: [true, 'Please specify price per night in USD'],
      min: [1, 'Price per night must be at least $1'],
    },
    cleaningFee: {
      type: Number,
      default: 45,
    },
    serviceFee: {
      type: Number,
      default: 25,
    },
    maxGuests: {
      type: Number,
      required: [true, 'Please specify maximum guest count'],
      min: [1, 'Guest capacity must be at least 1'],
      default: 2,
    },
    bedrooms: {
      type: Number,
      required: [true, 'Please specify bedrooms count'],
      default: 1,
    },
    beds: {
      type: Number,
      required: [true, 'Please specify beds count'],
      default: 1,
    },
    bathrooms: {
      type: Number,
      required: [true, 'Please specify bathrooms count'],
      default: 1,
    },
    amenities: {
      type: [String],
      default: ['Wifi', 'Kitchen', 'Air conditioning', 'Free parking'],
    },
    images: {
      type: [String],
      required: [true, 'Please provide at least one photo'],
      validate: [val => val.length > 0, 'At least one photo is required'],
    },
    host: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    rating: {
      type: Number,
      default: 4.85,
      min: 0,
      max: 5,
    },
    numReviews: {
      type: Number,
      default: 0,
    },
    isFeatured: {
      type: Boolean,
      default: false,
    },
  },
  {
    timestamps: true,
  }
);

listingSchema.index({ 'location.city': 'text', 'location.country': 'text', title: 'text', description: 'text' });

const Listing = mongoose.model('Listing', listingSchema);
module.exports = Listing;
