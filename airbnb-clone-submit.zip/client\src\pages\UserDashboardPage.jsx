import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate, Link } from 'react-router-dom';
import {
  Calendar,
  Home,
  Compass,
  User as UserIcon,
  Trash2,
  Edit3,
  ExternalLink,
  PlusCircle,
  AlertCircle,
  CheckCircle,
  Clock,
  MapPin,
  DollarSign,
  Phone,
  Mail,
  ShieldCheck,
} from 'lucide-react';
import { bookingApi } from '../api/bookingApi';
import { listingApi } from '../api/listingApi';
import { useAuth } from '../context/AuthContext';

const UserDashboardPage = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const { user, isAuthenticated, openAuthModal, updateProfile } = useAuth();

  const activeTab = searchParams.get('tab') || 'trips';

  // Data states
  const [trips, setTrips] = useState([]);
  const [myListings, setMyListings] = useState([]);
  const [hostReservations, setHostReservations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [successMsg, setSuccessMsg] = useState('');

  // Profile Form state
  const [name, setName] = useState(user?.name || '');
  const [bio, setBio] = useState(user?.bio || '');
  const [phone, setPhone] = useState(user?.phone || '');
  const [avatar, setAvatar] = useState(user?.avatar || '');
  const [savingProfile, setSavingProfile] = useState(false);

  useEffect(() => {
    if (user) {
      setName(user.name || '');
      setBio(user.bio || '');
      setPhone(user.phone || '');
      setAvatar(user.avatar || '');
    }
  }, [user]);

  // Load active tab data
  useEffect(() => {
    if (!isAuthenticated) return;

    const loadData = async () => {
      setLoading(true);
      setError(null);
      try {
        if (activeTab === 'trips') {
          const res = await bookingApi.getMyBookings();
          if (res.success) setTrips(res.bookings || []);
        } else if (activeTab === 'listings') {
          const res = await listingApi.getMyListings();
          if (res.success) setMyListings(res.listings || []);
        } else if (activeTab === 'reservations') {
          const res = await bookingApi.getHostReservations();
          if (res.success) setHostReservations(res.bookings || []);
        }
      } catch (err) {
        setError(err.response?.data?.message || err.message || 'Failed to fetch dashboard data');
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, [activeTab, isAuthenticated]);

  if (!isAuthenticated) {
    return (
      <div className="max-w-md mx-auto my-20 p-8 text-center bg-gray-50 border border-gray-200 rounded-3xl">
        <UserIcon className="w-12 h-12 text-airbnb mx-auto mb-3" />
        <h2 className="text-xl font-bold text-gray-900 mb-2">Access Dashboard</h2>
        <p className="text-xs text-gray-600 mb-6">Log in to view your bookings, manage listings, and update profile.</p>
        <button
          onClick={() => openAuthModal('login')}
          className="px-6 py-2.5 bg-airbnb hover:bg-airbnb-dark text-white rounded-xl text-sm font-semibold shadow-md"
        >
          Log in
        </button>
      </div>
    );
  }

  const handleTabChange = (tab) => {
    setSuccessMsg('');
    setError(null);
    setSearchParams({ tab });
  };

  const handleCancelBooking = async (bookingId) => {
    if (!window.confirm('Are you sure you want to cancel this reservation?')) return;

    try {
      const res = await bookingApi.cancel(bookingId);
      if (res.success) {
        setTrips((prev) =>
          prev.map((b) => (b._id === bookingId ? { ...b, status: 'cancelled' } : b))
        );
        setSuccessMsg('Reservation cancelled successfully.');
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to cancel booking.');
    }
  };

  const handleDeleteListing = async (listingId) => {
    if (!window.confirm('Are you sure you want to delete this listing? This action cannot be undone.')) return;

    try {
      const res = await listingApi.delete(listingId);
      if (res.success) {
        setMyListings((prev) => prev.filter((l) => l._id !== listingId));
        setSuccessMsg('Listing deleted successfully.');
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to delete listing.');
    }
  };

  const handleProfileSave = async (e) => {
    e.preventDefault();
    setSavingProfile(true);
    setSuccessMsg('');
    setError(null);

    const res = await updateProfile({ name, bio, phone, avatar });
    if (res.success) {
      setSuccessMsg('Profile updated successfully!');
    } else {
      setError(res.message);
    }
    setSavingProfile(false);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 pb-24">
      {/* Dashboard Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-6 border-b border-gray-200 gap-4 mb-8">
        <div className="flex items-center space-x-4">
          <img
            src={user?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80'}
            alt={user?.name}
            className="w-16 h-16 rounded-full object-cover border-2 border-airbnb shadow-xs"
          />
          <div>
            <h1 className="text-2xl font-bold text-gray-900">{user?.name}</h1>
            <p className="text-xs text-gray-500">{user?.email}</p>
            <div className="flex items-center space-x-2 mt-1">
              <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-rose-50 text-airbnb">
                {user?.role === 'admin' ? 'Administrator' : user?.role === 'host' ? 'Superhost' : 'Traveler'}
              </span>
            </div>
          </div>
        </div>

        <Link
          to="/create-listing"
          className="inline-flex items-center space-x-2 px-5 py-2.5 bg-gradient-to-r from-airbnb to-airbnb-dark text-white rounded-xl text-xs font-bold shadow-md hover:opacity-95 transition"
        >
          <PlusCircle className="w-4 h-4" />
          <span>Airbnb your home</span>
        </Link>
      </div>

      {/* Tabs Bar */}
      <div className="flex border-b border-gray-200 overflow-x-auto no-scrollbar space-x-8 text-sm font-semibold mb-8">
        {[
          { id: 'trips', label: 'My Trips & Bookings', icon: Calendar, count: trips.length },
          { id: 'listings', label: 'My Listings (Host)', icon: Home, count: myListings.length },
          { id: 'reservations', label: 'Host Reservations', icon: Compass, count: hostReservations.length },
          { id: 'profile', label: 'Profile Settings', icon: UserIcon },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => handleTabChange(tab.id)}
              className={`flex items-center space-x-2 pb-4 border-b-2 transition whitespace-nowrap ${
                isActive
                  ? 'border-gray-900 text-gray-900'
                  : 'border-transparent text-gray-500 hover:text-gray-800'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
              {tab.count !== undefined && tab.count > 0 && (
                <span className="bg-gray-100 text-gray-700 text-xs px-2 py-0.5 rounded-full">
                  {tab.count}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Messages */}
      {successMsg && (
        <div className="mb-6 p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center space-x-2 font-medium">
          <CheckCircle className="w-5 h-5 flex-shrink-0 text-emerald-600" />
          <span>{successMsg}</span>
        </div>
      )}

      {error && (
        <div className="mb-6 p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center space-x-2 font-medium">
          <AlertCircle className="w-5 h-5 flex-shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Loading Skeletons */}
      {loading && activeTab !== 'profile' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-pulse">
          {Array.from({ length: 3 }).map((_, idx) => (
            <div key={idx} className="h-64 bg-gray-100 rounded-3xl"></div>
          ))}
        </div>
      )}

      {/* TAB 1: My Trips (Bookings) */}
      {!loading && activeTab === 'trips' && (
        <div>
          {trips.length === 0 ? (
            <div className="text-center py-16 bg-gray-50 rounded-3xl border border-gray-200 max-w-md mx-auto p-8">
              <Calendar className="w-12 h-12 text-gray-400 mx-auto mb-3" />
              <h3 className="text-base font-bold text-gray-900 mb-1">No trips booked... yet!</h3>
              <p className="text-xs text-gray-500 mb-5">
                Time to dust off your bags and start planning your next great adventure.
              </p>
              <button
                onClick={() => navigate('/')}
                className="px-6 py-2.5 bg-gray-900 hover:bg-black text-white text-xs font-semibold rounded-xl"
              >
                Start searching
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {trips.map((booking) => {
                const listing = booking.listing || {};
                const coverImage = listing.images && listing.images[0]
                  ? listing.images[0]
                  : 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=1200&q=80';

                return (
                  <div
                    key={booking._id}
                    className="border border-gray-200 rounded-3xl overflow-hidden shadow-xs hover:shadow-md transition bg-white flex flex-col justify-between"
                  >
                    <div>
                      <div className="relative aspect-video w-full overflow-hidden bg-gray-100">
                        <img
                          src={coverImage}
                          alt={listing.title}
                          className="w-full h-full object-cover"
                        />
                        <span
                          className={`absolute top-3 right-3 text-[11px] font-bold px-2.5 py-1 rounded-full shadow-xs ${
                            booking.status === 'confirmed'
                              ? 'bg-emerald-500 text-white'
                              : 'bg-rose-500 text-white'
                          }`}
                        >
                          {booking.status === 'confirmed' ? 'Confirmed Stay' : 'Cancelled'}
                        </span>
                      </div>

                      <div className="p-5 space-y-3">
                        <div className="flex items-center space-x-1 text-xs text-gray-500">
                          <MapPin className="w-3.5 h-3.5 text-gray-400" />
                          <span>{listing.location?.city}, {listing.location?.country}</span>
                        </div>

                        <h3 className="font-bold text-gray-900 text-sm line-clamp-1">
                          {listing.title || 'Reserved Property'}
                        </h3>

                        <div className="p-3 bg-gray-50 rounded-2xl text-xs space-y-1.5 text-gray-600">
                          <div className="flex justify-between">
                            <span className="font-medium">Dates:</span>
                            <span className="font-semibold text-gray-900">
                              {new Date(booking.checkIn).toLocaleDateString()} - {new Date(booking.checkOut).toLocaleDateString()}
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span className="font-medium">Stay Duration:</span>
                            <span>{booking.nights} night{booking.nights > 1 ? 's' : ''}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="font-medium">Guests:</span>
                            <span>{booking.totalGuests || 1} guest(s)</span>
                          </div>
                          <div className="flex justify-between border-t border-gray-200 pt-1.5 font-bold text-gray-900">
                            <span>Total Paid:</span>
                            <span className="text-airbnb">${booking.totalPrice}</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="px-5 pb-5 pt-1 flex items-center justify-between border-t border-gray-100 gap-2">
                      <Link
                        to={`/listings/${listing._id}`}
                        className="text-xs font-semibold text-gray-800 hover:text-black flex items-center space-x-1"
                      >
                        <span>View Place</span>
                        <ExternalLink className="w-3 h-3" />
                      </Link>

                      {booking.status === 'confirmed' && (
                        <button
                          onClick={() => handleCancelBooking(booking._id)}
                          className="px-3 py-1.5 border border-rose-200 text-rose-600 hover:bg-rose-50 rounded-xl text-xs font-semibold transition"
                        >
                          Cancel Stay
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* TAB 2: My Listings (Host Hub) */}
      {!loading && activeTab === 'listings' && (
        <div>
          {myListings.length === 0 ? (
            <div className="text-center py-16 bg-gray-50 rounded-3xl border border-gray-200 max-w-md mx-auto p-8">
              <Home className="w-12 h-12 text-gray-400 mx-auto mb-3" />
              <h3 className="text-base font-bold text-gray-900 mb-1">No property listings yet</h3>
              <p className="text-xs text-gray-500 mb-5">
                Join thousands of hosts earning extra income by listing their space on Airbnb.
              </p>
              <Link
                to="/create-listing"
                className="px-6 py-2.5 bg-airbnb hover:bg-airbnb-dark text-white text-xs font-semibold rounded-xl inline-block shadow-md"
              >
                Create your first listing
              </Link>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {myListings.map((listing) => (
                <div
                  key={listing._id}
                  className="border border-gray-200 rounded-3xl overflow-hidden shadow-xs hover:shadow-md transition bg-white flex flex-col justify-between"
                >
                  <div>
                    <div className="relative aspect-video w-full overflow-hidden bg-gray-100">
                      <img
                        src={listing.images[0]}
                        alt={listing.title}
                        className="w-full h-full object-cover"
                      />
                      <span className="absolute top-3 left-3 bg-white/90 backdrop-blur-xs text-gray-900 text-[10px] font-bold px-2.5 py-1 rounded-full shadow-xs">
                        {listing.category}
                      </span>
                    </div>

                    <div className="p-5 space-y-2">
                      <p className="text-xs text-gray-500">
                        {listing.location.city}, {listing.location.country}
                      </p>
                      <h3 className="font-bold text-gray-900 text-sm line-clamp-1">
                        {listing.title}
                      </h3>
                      <div className="flex items-center space-x-1 text-xs">
                        <span className="font-bold text-sm text-gray-900">${listing.pricePerNight}</span>
                        <span className="text-gray-500">/ night</span>
                        <span className="text-gray-300 mx-2">•</span>
                        <span className="text-gray-600">{listing.bedrooms} bed, {listing.bathrooms} bath</span>
                      </div>
                    </div>
                  </div>

                  <div className="px-5 pb-5 pt-3 border-t border-gray-100 flex items-center justify-between text-xs">
                    <Link
                      to={`/listings/${listing._id}`}
                      className="font-semibold text-gray-600 hover:text-black flex items-center space-x-1"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      <span>View</span>
                    </Link>

                    <div className="flex items-center space-x-2">
                      <Link
                        to={`/edit-listing/${listing._id}`}
                        className="p-2 border border-gray-200 hover:border-gray-900 rounded-xl text-gray-700 transition"
                        title="Edit Listing"
                      >
                        <Edit3 className="w-4 h-4" />
                      </Link>

                      <button
                        onClick={() => handleDeleteListing(listing._id)}
                        className="p-2 border border-rose-200 text-rose-600 hover:bg-rose-50 rounded-xl transition"
                        title="Delete Listing"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 3: Host Reservations (Bookings on User's Properties) */}
      {!loading && activeTab === 'reservations' && (
        <div>
          {hostReservations.length === 0 ? (
            <div className="text-center py-16 bg-gray-50 rounded-3xl border border-gray-200 max-w-md mx-auto p-8">
              <Compass className="w-12 h-12 text-gray-400 mx-auto mb-3" />
              <h3 className="text-base font-bold text-gray-900 mb-1">No reservations yet</h3>
              <p className="text-xs text-gray-500">
                When travelers book your published listings, their reservations and earnings will appear here.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {hostReservations.map((res) => (
                <div
                  key={res._id}
                  className="p-5 border border-gray-200 rounded-3xl bg-white flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xs"
                >
                  <div className="flex items-center space-x-4">
                    <img
                      src={res.user?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80'}
                      alt={res.user?.name}
                      className="w-12 h-12 rounded-full object-cover border border-gray-200"
                    />
                    <div>
                      <p className="font-bold text-sm text-gray-900">{res.user?.name || 'Guest'}</p>
                      <p className="text-xs text-gray-500">{res.user?.email}</p>
                      <p className="text-xs text-gray-800 font-medium mt-0.5">
                        Property: <strong className="text-gray-900">{res.listing?.title}</strong>
                      </p>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-6 text-xs text-gray-600">
                    <div>
                      <span className="block text-gray-400 font-semibold text-[10px] uppercase">Dates</span>
                      <span className="font-semibold text-gray-900">
                        {new Date(res.checkIn).toLocaleDateString()} - {new Date(res.checkOut).toLocaleDateString()}
                      </span>
                    </div>

                    <div>
                      <span className="block text-gray-400 font-semibold text-[10px] uppercase">Nights</span>
                      <span className="font-semibold text-gray-900">{res.nights}</span>
                    </div>

                    <div>
                      <span className="block text-gray-400 font-semibold text-[10px] uppercase">Payout</span>
                      <span className="font-bold text-emerald-600 text-sm">${res.totalPrice}</span>
                    </div>

                    <div>
                      <span
                        className={`text-[11px] font-bold px-3 py-1 rounded-full ${
                          res.status === 'confirmed'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : 'bg-rose-50 text-rose-700 border border-rose-200'
                        }`}
                      >
                        {res.status}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 4: Profile Settings */}
      {activeTab === 'profile' && (
        <div className="max-w-2xl bg-white border border-gray-200 rounded-3xl p-6 sm:p-8 shadow-xs">
          <h2 className="text-lg font-bold text-gray-900 mb-1">Personal Info & Profile</h2>
          <p className="text-xs text-gray-500 mb-6">Manage your contact details and host biography.</p>

          <form onSubmit={handleProfileSave} className="space-y-5">
            <div>
              <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Full Name</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-airbnb"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Email Address</label>
              <input
                type="email"
                disabled
                value={user?.email || ''}
                className="w-full p-3 bg-gray-100 border border-gray-200 rounded-xl text-sm text-gray-500 cursor-not-allowed"
              />
              <p className="text-[10px] text-gray-400 mt-1">Email address cannot be changed.</p>
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Phone Number</label>
              <input
                type="tel"
                placeholder="+1 (555) 000-0000"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-airbnb"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Avatar Image URL</label>
              <input
                type="url"
                placeholder="https://images.unsplash.com/..."
                value={avatar}
                onChange={(e) => setAvatar(e.target.value)}
                className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-airbnb"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 uppercase mb-1">About Me (Bio)</label>
              <textarea
                rows={3}
                placeholder="Tell guests and hosts a little about yourself, your interests, and travel stories..."
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-airbnb"
              />
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="submit"
                disabled={savingProfile}
                className="px-6 py-3 bg-gray-900 hover:bg-black text-white font-bold rounded-xl text-xs shadow-md transition disabled:opacity-50"
              >
                {savingProfile ? 'Saving...' : 'Save Profile Changes'}
              </button>
            </div>
          </form>
        </div>
      )}

    </div>
  );
};

export default UserDashboardPage;
