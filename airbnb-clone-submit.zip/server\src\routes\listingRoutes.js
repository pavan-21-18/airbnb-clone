const express = require('express');
const router = express.Router();
const {
  getAllListings,
  getListingById,
  createListing,
  updateListing,
  deleteListing,
  getHostListings,
  uploadListingImages,
} = require('../controllers/listingController');
const { protect, verifyHost } = require('../middleware/authMiddleware');
const upload = require('../middleware/uploadMiddleware');

router.get('/', getAllListings);
router.get('/host/my-listings', protect, getHostListings);
router.get('/:id', getListingById);

router.post('/', protect, verifyHost, createListing);
router.put('/:id', protect, verifyHost, updateListing);
router.delete('/:id', protect, verifyHost, deleteListing);

// Image upload route: handles up to 10 images at once
router.post('/upload', protect, upload.array('images', 10), uploadListingImages);

module.exports = router;
