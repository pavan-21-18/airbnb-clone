import React, { useState } from 'react';
import { Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import SearchModal from './components/SearchModal';
import AuthModal from './components/AuthModal';
import HomePage from './pages/HomePage';
import ListingDetailPage from './pages/ListingDetailPage';
import CreateListingPage from './pages/CreateListingPage';
import EditListingPage from './pages/EditListingPage';
import UserDashboardPage from './pages/UserDashboardPage';

function App() {
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  return (
    <div className="min-h-screen flex flex-col bg-white text-gray-900">
      {/* Top Navigation Bar */}
      <Navbar onOpenSearch={() => setIsSearchOpen(true)} />

      {/* Main Page Routing */}
      <div className="flex-1">
        <Routes>
          <Route path="/" element={<HomePage onOpenSearch={() => setIsSearchOpen(true)} />} />
          <Route path="/listings/:id" element={<ListingDetailPage />} />
          <Route path="/create-listing" element={<CreateListingPage />} />
          <Route path="/edit-listing/:id" element={<EditListingPage />} />
          <Route path="/dashboard" element={<UserDashboardPage />} />
          <Route
            path="*"
            element={
              <div className="text-center py-24">
                <h1 className="text-3xl font-bold mb-2">404 - Page Not Found</h1>
                <p className="text-gray-500 mb-6 text-sm">We can't seem to find the page you're looking for.</p>
                <a href="/" className="px-5 py-2.5 bg-gray-900 text-white rounded-xl text-xs font-semibold">
                  Return to Home
                </a>
              </div>
            }
          />
        </Routes>
      </div>

      {/* Global Modals */}
      <SearchModal isOpen={isSearchOpen} onClose={() => setIsSearchOpen(false)} />
      <AuthModal />

      {/* Footer */}
      <Footer />
    </div>
  );
}

export default App;
