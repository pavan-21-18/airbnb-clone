import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Upload,
  Plus,
  Trash2,
  Home,
  DollarSign,
  MapPin,
  Check,
  AlertCircle,
  Sparkles,
} from 'lucide-react';
import { listingApi } from '../api/listingApi';
import { useAuth } from '../context/AuthContext';

const categoriesList = [
  'Beachfront',
  'Cabins',
  'Iconic Cities',
  'Lakefront',
  'Mansions',
  'Countryside',
  'Tiny Homes',
  'Trending',
  'Mountains',
  'Camping',
  'Villas',
];

const propertyTypes = ['Apartment', 'House', 'Villa', 'Cabin', 'Studio', 'Condo', 'Cottage'];
const roomTypes = ['Entire place', 'Private room', 'Shared room'];

const allAmenities = [
  'Wifi',
  'Kitchen',
  'Air conditioning',
  'Free parking',
  'Pool',
  'Hot tub',
  'TV',
  'Dedicated workspace',
  'EV charger',
  'Ocean view',
  'Mountain view',
  'BBQ grill',
  'Pets allowed',
  'Washer',
  'Gym',
];

const sampleImagePresets = [
  'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=1200&q=80',
  'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80',
  'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=1200&q=80',
];

const CreateListingPage = () => {
  const navigate = useNavigate();
  const { isAuthenticated, openAuthModal } = useAuth();

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('Beachfront');
  const [propertyType, setPropertyType] = useState('Apartment');
  const [roomType, setRoomType] = useState('Entire place');

  // Location
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('');
  const [country, setCountry] = useState('');
  const [zipCode, setZipCode] = useState('');

  // Capacity & Pricing
  const [maxGuests, setMaxGuests] = useState(2);
  const [bedrooms, setBedrooms] = useState(1);
  const [beds, setBeds] = useState(1);
  const [bathrooms, setBathrooms] = useState(1);
  const [pricePerNight, setPricePerNight] = useState(150);
  const [cleaningFee, setCleaningFee] = useState(40);

  // Amenities & Images
  const [amenities, setAmenities] = useState(['Wifi', 'Kitchen', 'Air conditioning']);
  const [images, setImages] = useState(sampleImagePresets);
  const [customImageUrl, setCustomImageUrl] = useState('');
  const [uploading, setUploading] = useState(false);

  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  // Redirect or show modal if unauthenticated
  if (!isAuthenticated) {
    return (
      <div className="max-w-md mx-auto my-20 p-8 text-center bg-gray-50 border border-gray-200 rounded-3xl">
        <Home className="w-12 h-12 text-airbnb mx-auto mb-3" />
        <h2 className="text-xl font-bold text-gray-900 mb-2">Host on Airbnb</h2>
        <p className="text-xs text-gray-600 mb-6">You must be logged in to create and manage property listings.</p>
        <button
          onClick={() => openAuthModal('login')}
          className="px-6 py-2.5 bg-airbnb hover:bg-airbnb-dark text-white rounded-xl text-sm font-semibold shadow-md"
        >
          Log in to continue
        </button>
      </div>
    );
  }

  const toggleAmenity = (item) => {
    if (amenities.includes(item)) {
      setAmenities(amenities.filter((a) => a !== item));
    } else {
      setAmenities([...amenities, item]);
    }
  };

  const handleFileUpload = async (e) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const formData = new FormData();
    for (let i = 0; i < files.length; i++) {
      formData.append('images', files[i]);
    }

    setUploading(true);
    setError('');
    try {
      const res = await listingApi.uploadImages(formData);
      if (res.success && res.images) {
        setImages((prev) => [...prev, ...res.images]);
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to upload photo(s).');
    } finally {
      setUploading(false);
    }
  };

  const addImageUrl = () => {
    if (!customImageUrl.trim()) return;
    setImages((prev) => [...prev, customImageUrl.trim()]);
    setCustomImageUrl('');
  };

  const removeImage = (index) => {
    setImages(images.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    if (images.length === 0) {
      setError('Please provide at least one photo for your property.');
      return;
    }

    setSubmitting(true);
    try {
      const payload = {
        title,
        description,
        category,
        propertyType,
        roomType,
        location: {
          address,
          city,
          state,
          country,
          zipCode,
        },
        pricePerNight: Number(pricePerNight),
        cleaningFee: Number(cleaningFee),
        maxGuests: Number(maxGuests),
        bedrooms: Number(bedrooms),
        beds: Number(beds),
        bathrooms: Number(bathrooms),
        amenities,
        images,
      };

      const res = await listingApi.create(payload);
      if (res.success) {
        navigate(`/listings/${res.listing._id}`);
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to create listing. Check all fields.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 pb-24">
      <div className="mb-8">
        <h1 className="text-3xl font-extrabold text-gray-900">List your property on Airbnb</h1>
        <p className="text-sm text-gray-500 mt-1">
          Share your space with travelers from around the world in a few simple steps.
        </p>
      </div>

      {error && (
        <div className="mb-6 p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center space-x-2 font-medium">
          <AlertCircle className="w-5 h-5 flex-shrink-0" />
          <span>{error}</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-10">
        
        {/* Section 1: Basic Information */}
        <div className="bg-white border border-gray-200 rounded-3xl p-6 sm:p-8 space-y-6 shadow-xs">
          <h2 className="text-lg font-bold text-gray-900 border-b border-gray-100 pb-3">
            1. Property Overview
          </h2>

          <div>
            <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Listing Title</label>
            <input
              type="text"
              required
              maxLength={100}
              placeholder="e.g. Sunny Oceanfront Suite with Heated Pool"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl text-sm font-medium focus:bg-white focus:outline-none focus:ring-2 focus:ring-airbnb"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Description</label>
            <textarea
              rows={4}
              required
              maxLength={2000}
              placeholder="Describe your space, atmosphere, neighborhood highlights, and what makes it special..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:bg-white focus:outline-none focus:ring-2 focus:ring-airbnb"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-airbnb"
              >
                {categoriesList.map((cat) => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Property Type</label>
              <select
                value={propertyType}
                onChange={(e) => setPropertyType(e.target.value)}
                className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-airbnb"
              >
                {propertyTypes.map((t) => (
                  <option key={t} value={t}>{t}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Room Type</label>
              <select
                value={roomType}
                onChange={(e) => setRoomType(e.target.value)}
                className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-airbnb"
              >
                {roomTypes.map((rt) => (
                  <option key={rt} value={rt}>{rt}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Section 2: Location */}
        <div className="bg-white border border-gray-200 rounded-3xl p-6 sm:p-8 space-y-6 shadow-xs">
          <h2 className="text-lg font-bold text-gray-900 border-b border-gray-100 pb-3 flex items-center space-x-2">
            <MapPin className="w-5 h-5 text-airbnb" />
            <span>2. Location</span>
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Street Address</label>
              <input
                type="text"
                required
                placeholder="e.g. 120 Ocean Avenue"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-airbnb"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 uppercase mb-1">City</label>
              <input
                type="text"
                required
                placeholder="e.g. Malibu"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-airbnb"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 uppercase mb-1">State / Province</label>
              <input
                type="text"
                required
                placeholder="e.g. California"
                value={state}
                onChange={(e) => setState(e.target.value)}
                className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-airbnb"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Country</label>
              <input
                type="text"
                required
                placeholder="e.g. United States"
                value={country}
                onChange={(e) => setCountry(e.target.value)}
                className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-airbnb"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Postal Code</label>
              <input
                type="text"
                placeholder="e.g. 90265"
                value={zipCode}
                onChange={(e) => setZipCode(e.target.value)}
                className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-airbnb"
              />
            </div>
          </div>
        </div>

        {/* Section 3: Capacity & Pricing */}
        <div className="bg-white border border-gray-200 rounded-3xl p-6 sm:p-8 space-y-6 shadow-xs">
          <h2 className="text-lg font-bold text-gray-900 border-b border-gray-100 pb-3 flex items-center space-x-2">
            <DollarSign className="w-5 h-5 text-airbnb" />
            <span>3. Capacity & Pricing</span>
          </h2>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div>
              <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Max Guests</label>
              <input
                type="number"
                min={1}
                max={30}
                required
                value={maxGuests}
                onChange={(e) => setMaxGuests(Number(e.target.value))}
                className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-airbnb"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Bedrooms</label>
              <input
                type="number"
                min={1}
                max={20}
                required
                value={bedrooms}
                onChange={(e) => setBedrooms(Number(e.target.value))}
                className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-airbnb"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Beds</label>
              <input
                type="number"
                min={1}
                max={30}
                required
                value={beds}
                onChange={(e) => setBeds(Number(e.target.value))}
                className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-airbnb"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Bathrooms</label>
              <input
                type="number"
                min={1}
                max={20}
                required
                value={bathrooms}
                onChange={(e) => setBathrooms(Number(e.target.value))}
                className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-airbnb"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
            <div>
              <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Nightly Price ($ USD)</label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 font-bold text-gray-400">$</span>
                <input
                  type="number"
                  min={1}
                  required
                  value={pricePerNight}
                  onChange={(e) => setPricePerNight(Number(e.target.value))}
                  className="w-full pl-8 pr-3 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm font-bold text-gray-900 focus:outline-none focus:ring-2 focus:ring-airbnb"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Cleaning Fee ($ USD)</label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 font-bold text-gray-400">$</span>
                <input
                  type="number"
                  min={0}
                  value={cleaningFee}
                  onChange={(e) => setCleaningFee(Number(e.target.value))}
                  className="w-full pl-8 pr-3 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm font-bold text-gray-900 focus:outline-none focus:ring-2 focus:ring-airbnb"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Section 4: Amenities */}
        <div className="bg-white border border-gray-200 rounded-3xl p-6 sm:p-8 space-y-6 shadow-xs">
          <h2 className="text-lg font-bold text-gray-900 border-b border-gray-100 pb-3">
            4. Amenities
          </h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {allAmenities.map((item) => {
              const isChecked = amenities.includes(item);
              return (
                <button
                  key={item}
                  type="button"
                  onClick={() => toggleAmenity(item)}
                  className={`flex items-center space-x-2.5 p-3 rounded-2xl border text-xs text-left transition ${
                    isChecked
                      ? 'border-gray-900 bg-gray-50 text-gray-900 font-semibold shadow-xs'
                      : 'border-gray-200 text-gray-600 hover:border-gray-400'
                  }`}
                >
                  <div
                    className={`w-4 h-4 rounded border flex items-center justify-center transition ${
                      isChecked ? 'bg-airbnb border-airbnb text-white' : 'border-gray-300'
                    }`}
                  >
                    {isChecked && <Check className="w-3 h-3 stroke-[3]" />}
                  </div>
                  <span>{item}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Section 5: Photos (Multer File Upload + URL Input) */}
        <div className="bg-white border border-gray-200 rounded-3xl p-6 sm:p-8 space-y-6 shadow-xs">
          <h2 className="text-lg font-bold text-gray-900 border-b border-gray-100 pb-3 flex items-center space-x-2">
            <Upload className="w-5 h-5 text-airbnb" />
            <span>5. Photos & Image Uploads</span>
          </h2>

          {/* File Upload Box */}
          <div className="border-2 border-dashed border-gray-300 hover:border-airbnb rounded-3xl p-8 text-center transition cursor-pointer relative bg-gray-50/50">
            <input
              type="file"
              multiple
              accept="image/*"
              onChange={handleFileUpload}
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
            />
            <Upload className="w-10 h-10 text-gray-400 mx-auto mb-2" />
            <p className="text-sm font-semibold text-gray-800">
              {uploading ? 'Uploading image(s)...' : 'Upload photos from your computer'}
            </p>
            <p className="text-xs text-gray-400 mt-1">PNG, JPG, WEBP up to 10MB each (processed by Multer)</p>
          </div>

          {/* Add via direct URL input */}
          <div className="flex items-center space-x-2">
            <input
              type="url"
              placeholder="Or paste an image web link (e.g. Unsplash photo URL)"
              value={customImageUrl}
              onChange={(e) => setCustomImageUrl(e.target.value)}
              className="flex-1 p-3 bg-gray-50 border border-gray-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-airbnb"
            />
            <button
              type="button"
              onClick={addImageUrl}
              className="px-4 py-3 bg-gray-100 hover:bg-gray-200 text-gray-800 rounded-xl text-xs font-bold transition flex items-center space-x-1"
            >
              <Plus className="w-4 h-4" />
              <span>Add URL</span>
            </button>
          </div>

          {/* Image Previews */}
          {images.length > 0 && (
            <div>
              <p className="text-xs font-semibold text-gray-600 mb-2">
                Selected Photos ({images.length}):
              </p>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {images.map((img, idx) => (
                  <div key={idx} className="relative aspect-video rounded-xl overflow-hidden group border border-gray-200">
                    <img src={img} alt="Property preview" className="w-full h-full object-cover" />
                    <button
                      type="button"
                      onClick={() => removeImage(idx)}
                      className="absolute top-1.5 right-1.5 bg-black/70 hover:bg-rose-600 text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                    {idx === 0 && (
                      <span className="absolute bottom-1.5 left-1.5 bg-black/80 text-white text-[9px] font-bold px-2 py-0.5 rounded">
                        Cover Photo
                      </span>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Submit Button */}
        <div className="flex items-center justify-end space-x-4">
          <button
            type="button"
            onClick={() => navigate('/')}
            className="px-6 py-3 rounded-full text-sm font-semibold text-gray-600 hover:bg-gray-100 transition"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={submitting}
            className="px-8 py-3.5 bg-gradient-to-r from-airbnb to-airbnb-dark hover:opacity-95 text-white font-bold rounded-full text-sm shadow-md transition transform active:scale-95 disabled:opacity-50"
          >
            {submitting ? 'Creating Listing...' : 'Publish Listing'}
          </button>
        </div>

      </form>
    </div>
  );
};

export default CreateListingPage;
