# Airbnb Clone — MERN Stack Capstone Project (Module - 8)

A full-featured, responsive **Airbnb Clone** web application built with the **MERN Stack** (MongoDB, Express.js, React.js, Node.js), Tailwind CSS, and JSON Web Token (JWT) authentication. It allows travelers to explore unique accommodations across the world, filter properties, check real-time availability, and make bookings, while empowering hosts to list, manage, and monetize their properties.

---

## 🚀 Live Demo & Quick Credentials

For testing and grading convenience, one-click demo login buttons are integrated directly into the login modal. You can also use the following pre-seeded credentials:

| Role | Email | Password | Privileges |
| :--- | :--- | :--- | :--- |
| **Superhost** | `host@example.com` | `password123` | Create, edit, and delete listings; view host earnings & reservations |
| **Traveler Guest** | `guest@example.com` | `password123` | Search, filter, book stays; manage trips; submit reviews |
| **Administrator** | `admin@example.com` | `admin123` | Full administrative access |

---

## 🛠 Tech Stack

### Frontend
- **React.js 19** — Component-driven dynamic single-page user interface
- **React Router 7** — Client-side declarative routing and URL query parameter state synchronization
- **Tailwind CSS 3** — Modern utility-first responsive styling emulating Airbnb's design system
- **Axios** — HTTP client with Bearer token interceptor and centralized error handling
- **Lucide React** — Modern, clean icon suite
- **Vite** — Lightning-fast build tooling and hot module replacement (HMR)

### Backend
- **Node.js** — JavaScript runtime environment
- **Express.js 4** — Fast, RESTful API framework
- **MongoDB & Mongoose 8** — Object Data Modeling (ODM) with schemas, relationship population, and rating aggregation
- **MongoDB In-Memory Server Fallback** — Automatic zero-setup embedded MongoDB instance when no local MongoDB service is detected, enabling 100% plug-and-play local execution without database configuration barriers
- **JWT (JSON Web Tokens)** — Stateless, secure user authentication and session management
- **Bcrypt.js** — Salt hashing for secure user passwords
- **Multer** — Middleware for handling multipart/form-data image uploads
- **Morgan & CORS** — Request logging and cross-origin resource sharing

### Additional Tools & Testing
- **Dotenv** — Environment variable management
- **Postman Collection** — Included `airbnb-api.postman_collection.json` containing pre-configured requests for every backend endpoint

---

## ✨ Key Features Implemented

### 1. User Authentication & Authorization
- Secure user registration and login with bcrypt password encryption.
- JWT token generation and storage in `localStorage`.
- Automatic authorization header injection via Axios request interceptors.
- Role-based capabilities (`user`, `host`, `admin`).
- 1-click evaluator demo logins for instant testing without manual typing.

### 2. Property Listings (CRUD)
- **Browse & View**: High-resolution image galleries, Airbnb 5-photo collage grid, modal full-view gallery.
- **Create Listing ("Airbnb your home")**: Multi-section host form with category picker, property/room types, address, guest capacity, pricing, cleaning fees, amenity checkboxes, and photos.
- **Image Uploads**: Supports local disk uploads via Multer (`POST /api/listings/upload`) as well as direct image web URLs.
- **Update & Delete**: Dedicated host management controls with ownership verification.

### 3. Search & Interactive Filters
- **Location Search**: Search by city, state, country, or property name.
- **Category Carousel**: One-click category filtering (Beachfront, Cabins, Iconic Cities, Lakefront, Mansions, Countryside, Tiny Homes, Trending, Camping, etc.).
- **Comprehensive Filter Modal**:
  - Minimum and maximum price filters
  - Sorting (Top Rated, Price: Low to High, Price: High to Low)
  - Property types (Apartment, House, Villa, Cabin, Cottage)
  - Bedrooms and bathrooms count
  - Amenities checklist (Wifi, Kitchen, Pool, Hot tub, AC, Dedicated workspace, EV charger, etc.)
- Active filter pill badges with one-click "Reset all" capability.

### 4. Booking & Reservation System
- **Interactive Sticky Booking Widget**: Dynamic calculation of nights, base price, cleaning fee, service fee, and total price.
- **Availability & Overlap Prevention**: Backend validation ensures that conflicting date ranges cannot be reserved for the same property.
- **Disabled Dates API**: Endpoint `/api/bookings/listing/:id/dates` provides booked ranges to protect against double booking.
- Instant reservation confirmation and automatic redirection to user's trips.

### 5. User Dashboard
- **My Trips & Bookings**: Displays all confirmed and completed stays with status badges, pricing breakdown, and a "Cancel Stay" option.
- **My Listings (Host Hub)**: View all hosted properties, add new stays, edit details, or delete listings.
- **Host Reservations**: Review incoming bookings made by travelers on the host's properties, with payout summaries and guest contact details.
- **Profile Settings**: View and update name, bio, phone number, and avatar image URL.

### 6. Reviews & Ratings
- Guests can post reviews with 1–5 star ratings and comments.
- Mongoose post-save hooks automatically recalculate and update the property's average star rating and review count.

---

## 📁 Project Architecture

```
airbnb-clone/
├── airbnb-api.postman_collection.json  # Complete Postman API Collection
├── package.json                        # Root workspace scripts
├── README.md                           # Documentation
│
├── server/                             # Express & MongoDB Backend
│   ├── .env                            # Active environment variables
│   ├── .env.example                    # Environment template
│   ├── package.json
│   ├── uploads/                        # Stored property images
│   └── src/
│       ├── server.js                   # Express app entry & seed trigger
│       ├── config/
│       │   └── db.js                   # Mongoose connection + MMS fallback
│       ├── models/
│       │   ├── User.js                 # User schema & bcrypt methods
│       │   ├── Listing.js              # Property listing schema
│       │   ├── Booking.js              # Reservation schema & pricing
│       │   └── Review.js               # Review schema & rating aggregator
│       ├── controllers/
│       │   ├── authController.js       # Register, login, profile
│       │   ├── listingController.js    # CRUD, search, filters, uploads
│       │   ├── bookingController.js    # Reservations, overlap check, trips
│       │   └── reviewController.js     # Post and fetch reviews
│       ├── middleware/
│       │   ├── authMiddleware.js       # JWT protection & host verification
│       │   ├── uploadMiddleware.js     # Multer file storage & mime filter
│       │   └── errorMiddleware.js      # 404 & unified error handler
│       ├── routes/
│       │   ├── authRoutes.js
│       │   ├── listingRoutes.js
│       │   ├── bookingRoutes.js
│       │   └── reviewRoutes.js
│       └── utils/
│           ├── generateToken.js        # JWT generation helper
│           └── seedData.js             # Sample luxury listings & users
│
└── client/                             # React & Vite Frontend
    ├── index.html
    ├── package.json
    ├── tailwind.config.js              # Airbnb brand styling
    ├── postcss.config.js
    └── src/
        ├── main.jsx                    # React root with AuthProvider & Router
        ├── App.jsx                     # Route declarations
        ├── index.css                   # Tailwind base directives
        ├── api/
        │   ├── axiosInstance.js        # Axios with JWT Bearer interceptor
        │   ├── authApi.js
        │   ├── listingApi.js
        │   ├── bookingApi.js
        │   └── reviewApi.js
        ├── context/
        │   └── AuthContext.jsx         # Global auth state & modals
        ├── components/
        │   ├── Navbar.jsx              # Header with search pill & user menu
        │   ├── Footer.jsx              # Airbnb footer with capstone info
        │   ├── CategoriesBar.jsx       # Category icons horizontal carousel
        │   ├── ListingCard.jsx         # Property card with photo carousel
        │   ├── SearchModal.jsx         # Destination & dates popup
        │   ├── FilterModal.jsx         # Price, amenities, rooms filter popup
        │   └── AuthModal.jsx           # Login/Signup modal + 1-click demo
        └── pages/
            ├── HomePage.jsx            # Main marketplace view
            ├── ListingDetailPage.jsx   # 5-photo grid, booking widget, reviews
            ├── CreateListingPage.jsx   # Become a Host listing creator
            ├── EditListingPage.jsx     # Update existing listing
            └── UserDashboardPage.jsx   # Trips, My Listings, Reservations, Profile
```

---

## 🏃 Setup & Running Instructions

### Prerequisites
- **Node.js** (v18 or higher recommended)
- **npm** (v9 or higher)

### 1. Clone or Open the Workspace
Navigate to the project root directory:
```bash
cd airbnb-clone
```

### 2. Install Dependencies
Run the following root script or install server and client individually:
```bash
# Install both backend and frontend dependencies
npm run install:all
```
*(Alternatively: `cd server && npm install`, then `cd ../client && npm install`)*

### 3. Start the Backend API Server
```bash
cd server
npm start
```
The server will boot on `http://localhost:5000`.
- If a local MongoDB instance is running, it connects to `mongodb://localhost:27017/airbnb_clone`.
- If local MongoDB is not running, it automatically spins up an in-memory MongoDB instance with pre-seeded luxury properties and demo users!

### 4. Start the Frontend Client
In a separate terminal:
```bash
cd client
npm run dev
```
Open your browser at `http://localhost:5173`.

---

## 📬 Postman API Testing

1. Open **Postman**.
2. Click **Import** in the top-left corner.
3. Select the file `airbnb-api.postman_collection.json` located in the root directory.
4. All endpoints are categorized under:
   - `Health Check`
   - `Authentication` (`Register`, `Login`, `Profile`)
   - `Listings` (`Get All`, `Search/Filter`, `Get By ID`, `Create`, `Update`, `Delete`, `Host Listings`)
   - `Bookings & Reservations` (`Create`, `My Bookings`, `Host Reservations`, `Check Dates`, `Cancel`)
   - `Reviews` (`Add Review`, `Get Reviews`)
5. The `baseUrl` environment variable defaults to `http://localhost:5000/api`.

---

## 🔒 Environment Variables Reference

### Backend (`server/.env`)
| Variable | Default Value | Description |
| :--- | :--- | :--- |
| `PORT` | `5000` | Port for the Express server |
| `MONGODB_URI` | `mongodb://localhost:27017/airbnb_clone` | MongoDB connection URI |
| `JWT_SECRET` | `super_secret_airbnb_jwt_key_...` | Key used to sign JWT tokens |
| `JWT_EXPIRES_IN` | `30d` | Lifetime of user tokens |
| `CLIENT_URL` | `http://localhost:5173` | Allowed frontend origin for CORS |

---

## 🎓 Capstone Module - 8 Evaluation Checklist

- [x] **MERN Stack Architecture** (MongoDB, Express, React, Node.js)
- [x] **Secure JWT Authentication** (Registration, login, protected routes, session persistence)
- [x] **Property Listings CRUD** (Add, view, edit, delete listings with photo uploads)
- [x] **Search & Multi-criteria Filtering** (Location, category, price, bedrooms, bathrooms, amenities)
- [x] **Booking Engine** (Date selection, nights calculation, pricing breakdown, overlap conflict check)
- [x] **User Dashboard** (Trips management, host listing hub, incoming reservation tracker, profile editing)
- [x] **Responsive Modern Design** (Tailwind CSS matching Airbnb UI with carousels and photo grids)
- [x] **Postman Collection & API Health Check** provided for frictionless grading
