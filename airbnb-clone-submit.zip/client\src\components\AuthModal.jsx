import React, { useState } from 'react';
import { X, Mail, Lock, User, AlertCircle, Sparkles } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const AuthModal = () => {
  const { isAuthModalOpen, closeAuthModal, authModalMode, setAuthModalMode, login, register } = useAuth();
  
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('user');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  if (!isAuthModalOpen) return null;

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSubmitting(true);

    try {
      if (authModalMode === 'login') {
        const res = await login(email, password);
        if (!res.success) {
          setError(res.message);
        }
      } else {
        if (!name.trim()) {
          setError('Please enter your full name');
          setSubmitting(false);
          return;
        }
        const res = await register({ name, email, password, role });
        if (!res.success) {
          setError(res.message);
        }
      }
    } catch (err) {
      setError(err.message || 'An unexpected error occurred');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDemoLogin = async (demoEmail, demoPassword) => {
    setError('');
    setSubmitting(true);
    setEmail(demoEmail);
    setPassword(demoPassword);
    const res = await login(demoEmail, demoPassword);
    if (!res.success) {
      setError(res.message);
    }
    setSubmitting(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-md w-full shadow-2xl overflow-hidden border border-gray-100 relative">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
          <button
            onClick={closeAuthModal}
            className="p-1.5 rounded-full hover:bg-gray-100 text-gray-500 hover:text-gray-900 transition"
          >
            <X className="w-5 h-5" />
          </button>
          <h3 className="font-bold text-gray-900 text-base">
            {authModalMode === 'login' ? 'Log in to Airbnb' : 'Sign up on Airbnb'}
          </h3>
          <div className="w-8" />
        </div>

        {/* Form Body */}
        <div className="p-6">
          {/* Welcome heading */}
          <div className="mb-5">
            <h2 className="text-xl font-bold text-gray-900">Welcome to Airbnb Clone</h2>
            <p className="text-xs text-gray-500 mt-1">Discover, book, or host unique stays across the globe.</p>
          </div>

          {error && (
            <div className="mb-4 p-3 rounded-xl bg-rose-50 border border-rose-200 flex items-center space-x-2 text-rose-700 text-xs font-medium">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {authModalMode === 'register' && (
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Full Name</label>
                <div className="relative">
                  <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <input
                    type="text"
                    required
                    placeholder="John Doe"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full pl-10 pr-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-airbnb text-sm"
                  />
                </div>
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">Email address</label>
              <div className="relative">
                <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type="email"
                  required
                  placeholder="name@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-10 pr-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-airbnb text-sm"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">Password</label>
              <div className="relative">
                <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type="password"
                  required
                  minLength={6}
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-10 pr-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-airbnb text-sm"
                />
              </div>
            </div>

            {authModalMode === 'register' && (
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">I want to:</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setRole('user')}
                    className={`py-2 px-3 text-xs font-semibold rounded-xl border transition ${
                      role === 'user'
                        ? 'border-airbnb bg-rose-50 text-airbnb'
                        : 'border-gray-200 text-gray-700 hover:border-gray-300'
                    }`}
                  >
                    Travel & Book Stays
                  </button>
                  <button
                    type="button"
                    onClick={() => setRole('host')}
                    className={`py-2 px-3 text-xs font-semibold rounded-xl border transition ${
                      role === 'host'
                        ? 'border-airbnb bg-rose-50 text-airbnb'
                        : 'border-gray-200 text-gray-700 hover:border-gray-300'
                    }`}
                  >
                    Host my home
                  </button>
                </div>
              </div>
            )}

            <button
              type="submit"
              disabled={submitting}
              className="w-full py-3 bg-gradient-to-r from-airbnb to-airbnb-dark hover:opacity-95 text-white font-bold rounded-xl text-sm shadow-md transition disabled:opacity-50"
            >
              {submitting
                ? 'Processing...'
                : authModalMode === 'login'
                ? 'Log in'
                : 'Agree & Join Airbnb'}
            </button>
          </form>

          {/* Quick Demo Credentials Buttons for Capstone Testing */}
          <div className="mt-5 pt-4 border-t border-gray-100">
            <div className="flex items-center space-x-1 text-xs font-bold text-gray-600 mb-2.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              <span>1-Click Evaluator Demo Logins:</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => handleDemoLogin('host@example.com', 'password123')}
                className="p-2 border border-purple-200 bg-purple-50/60 hover:bg-purple-100/70 rounded-xl text-[11px] font-semibold text-purple-900 transition text-left"
              >
                <div className="font-bold">Superhost Demo</div>
                <div className="text-[10px] text-purple-600 truncate">Sarah Jenkins</div>
              </button>
              <button
                type="button"
                onClick={() => handleDemoLogin('guest@example.com', 'password123')}
                className="p-2 border border-blue-200 bg-blue-50/60 hover:bg-blue-100/70 rounded-xl text-[11px] font-semibold text-blue-900 transition text-left"
              >
                <div className="font-bold">Guest Traveler Demo</div>
                <div className="text-[10px] text-blue-600 truncate">Alex Johnson</div>
              </button>
            </div>
          </div>

          {/* Switch Mode Footer */}
          <div className="mt-5 text-center text-xs text-gray-600">
            {authModalMode === 'login' ? (
              <p>
                Don't have an account?{' '}
                <button
                  type="button"
                  onClick={() => {
                    setError('');
                    setAuthModalMode('register');
                  }}
                  className="font-bold text-airbnb hover:underline"
                >
                  Sign up
                </button>
              </p>
            ) : (
              <p>
                Already have an account?{' '}
                <button
                  type="button"
                  onClick={() => {
                    setError('');
                    setAuthModalMode('login');
                  }}
                  className="font-bold text-airbnb hover:underline"
                >
                  Log in
                </button>
              </p>
            )}
          </div>

        </div>

      </div>
    </div>
  );
};

export default AuthModal;
