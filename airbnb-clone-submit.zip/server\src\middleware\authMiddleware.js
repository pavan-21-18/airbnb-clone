const jwt = require('jsonwebtoken');
const User = require('../models/User');

const protect = async (req, res, next) => {
  let token;

  if (
    req.headers.authorization &&
    req.headers.authorization.startsWith('Bearer')
  ) {
    try {
      token = req.headers.authorization.split(' ')[1];
      const decoded = jwt.verify(
        token,
        process.env.JWT_SECRET || 'super_secret_airbnb_jwt_key_2026_capstone_secure'
      );

      req.user = await User.findById(decoded.id).select('-password');
      if (!req.user) {
        return res.status(401).json({ success: false, message: 'User not found' });
      }

      next();
    } catch (error) {
      console.error('JWT verification error:', error.message);
      return res.status(401).json({ success: false, message: 'Not authorized, token failed' });
    }
  }

  if (!token) {
    return res.status(401).json({ success: false, message: 'Not authorized, no token provided' });
  }
};

const verifyHost = (req, res, next) => {
  if (req.user && (req.user.role === 'host' || req.user.role === 'admin' || req.user.role === 'user')) {
    // We allow any registered user to act as a host in this platform, automatically elevating role if desired
    next();
  } else {
    res.status(403).json({ success: false, message: 'Host privileges required' });
  }
};

module.exports = { protect, verifyHost };
