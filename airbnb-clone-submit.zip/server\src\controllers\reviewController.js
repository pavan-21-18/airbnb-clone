const Review = require('../models/Review');
const Listing = require('../models/Listing');

// @desc    Add review for a listing
// @route   POST /api/reviews
// @access  Private
const createReview = async (req, res) => {
  try {
    const {
      listingId,
      rating,
      comment,
      cleanliness = 5,
      accuracy = 5,
      communication = 5,
      location = 5,
      value = 5,
    } = req.body;

    if (!listingId || !rating || !comment) {
      return res.status(400).json({
        success: false,
        message: 'Please provide listing ID, star rating (1-5), and a review comment',
      });
    }

    const listing = await Listing.findById(listingId);
    if (!listing) {
      return res.status(404).json({ success: false, message: 'Listing not found' });
    }

    // Check if user already reviewed this listing
    const existingReview = await Review.findOne({
      listing: listingId,
      user: req.user._id,
    });

    if (existingReview) {
      return res.status(400).json({
        success: false,
        message: 'You have already submitted a review for this property',
      });
    }

    const review = await Review.create({
      listing: listingId,
      user: req.user._id,
      rating: Number(rating),
      cleanliness: Number(cleanliness),
      accuracy: Number(accuracy),
      communication: Number(communication),
      location: Number(location),
      value: Number(value),
      comment,
    });

    const populatedReview = await Review.findById(review._id).populate(
      'user',
      'name avatar'
    );

    res.status(201).json({
      success: true,
      message: 'Review posted successfully',
      review: populatedReview,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get reviews for a listing
// @route   GET /api/reviews/listing/:listingId
// @access  Public
const getListingReviews = async (req, res) => {
  try {
    const reviews = await Review.find({ listing: req.params.listingId })
      .populate('user', 'name avatar')
      .sort({ createdAt: -1 });

    res.json({
      success: true,
      count: reviews.length,
      reviews,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

module.exports = {
  createReview,
  getListingReviews,
};
