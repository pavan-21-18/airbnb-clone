import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Star,
  MapPin,
  Share2,
  Heart,
  Wifi,
  Tv,
  Car,
  Utensils,
  Wind,
  ShieldCheck,
  Calendar as CalendarIcon,
  Users,
  CheckCircle,
  AlertCircle,
  X,
  ChevronRight,
  MessageSquare,
  Sparkles,
} from 'lucide-react';
import { listingApi } from '../api/listingApi';
import { bookingApi } from '../api/bookingApi';
import { reviewApi } from '../api/reviewApi';
import { useAuth } from '../context/AuthContext';

const amenityIcons = {
  Wifi: Wifi,
  Kitchen: Utensils,
  TV: Tv,
  'Free parking': Car,
  'Air conditioning': Wind,
};

const ListingDetailPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user, isAuthenticated, openAuthModal } = useAuth();

  const [listing, setListing] = useState(null);
  const [reviews, setReviews] = useState([]);
  const [bookedDates, setBookedDates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Booking state
  const [checkIn, setCheckIn] = useState('');
  const [checkOut, setCheckOut] = useState('');
  const [guests, setGuests] = useState(1);
  const [bookingLoading, setBookingLoading] = useState(false);
  const [bookingError, setBookingError] = useState('');
  const [bookingSuccess, setBookingSuccess] = useState(false);

  // Review submission state
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewComment, setReviewComment] = useState('');
  const [reviewSubmitting, setReviewSubmitting] = useState(false);
  const [reviewMsg, setReviewMsg] = useState('');

  // Photo modal
  const [isPhotoModalOpen, setIsPhotoModalOpen] = useState(false);

  useEffect(() => {
    const fetchListingData = async () => {
      setLoading(true);
      setError(null);
      try {
        const [listingRes, reviewsRes, datesRes] = await Promise.all([
          listingApi.getById(id),
          reviewApi.getByListing(id),
          bookingApi.getBookedDates(id),
        ]);

        if (listingRes.success) {
          setListing(listingRes.listing);
        }
        if (reviewsRes.success) {
          setReviews(reviewsRes.reviews || []);
        }
        if (datesRes.success) {
          setBookedDates(datesRes.bookedDates || []);
        }
      } catch (err) {
        setError(err.response?.data?.message || err.message || 'Failed to load property');
      } finally {
        setLoading(false);
      }
    };

    fetchListingData();
  }, [id]);

  // Calculate nights and prices
  let nights = 0;
  let basePrice = 0;
  let cleaningFee = 0;
  let serviceFee = 0;
  let totalPrice = 0;

  if (checkIn && checkOut && listing) {
    const start = new Date(checkIn);
    const end = new Date(checkOut);
    if (end > start) {
      const diffTime = Math.abs(end - start);
      nights = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      basePrice = nights * listing.pricePerNight;
      cleaningFee = listing.cleaningFee || 40;
      serviceFee = listing.serviceFee || Math.round(basePrice * 0.12);
      totalPrice = basePrice + cleaningFee + serviceFee;
    }
  }

  const handleBooking = async (e) => {
    e.preventDefault();
    setBookingError('');

    if (!isAuthenticated) {
      openAuthModal('login');
      return;
    }

    if (!checkIn || !checkOut) {
      setBookingError('Please select both check-in and check-out dates.');
      return;
    }

    if (nights <= 0) {
      setBookingError('Check-out date must be after check-in date.');
      return;
    }

    setBookingLoading(true);
    try {
      const res = await bookingApi.create({
        listingId: listing._id,
        checkIn,
        checkOut,
        guests: { adults: guests, children: 0, infants: 0 },
      });

      if (res.success) {
        setBookingSuccess(true);
        setTimeout(() => {
          navigate('/dashboard?tab=trips');
        }, 1800);
      }
    } catch (err) {
      setBookingError(err.response?.data?.message || 'Booking failed. Try different dates.');
    } finally {
      setBookingLoading(false);
    }
  };

  const handleReviewSubmit = async (e) => {
    e.preventDefault();
    if (!isAuthenticated) {
      openAuthModal('login');
      return;
    }

    if (!reviewComment.trim()) return;

    setReviewSubmitting(true);
    setReviewMsg('');
    try {
      const res = await reviewApi.create({
        listingId: listing._id,
        rating: reviewRating,
        comment: reviewComment,
      });

      if (res.success) {
        setReviews([res.review, ...reviews]);
        setReviewComment('');
        setReviewMsg('Thank you! Your review has been posted.');
      }
    } catch (err) {
      setReviewMsg(err.response?.data?.message || 'Failed to post review.');
    } finally {
      setReviewSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-12 animate-pulse space-y-6">
        <div className="h-8 bg-gray-200 rounded w-1/2"></div>
        <div className="h-4 bg-gray-200 rounded w-1/4"></div>
        <div className="h-[400px] bg-gray-200 rounded-3xl"></div>
      </div>
    );
  }

  if (error || !listing) {
    return (
      <div className="max-w-xl mx-auto my-20 p-8 text-center bg-rose-50 border border-rose-200 rounded-3xl">
        <AlertCircle className="w-12 h-12 text-rose-500 mx-auto mb-3" />
        <h2 className="text-xl font-bold text-gray-900 mb-2">Listing Not Found</h2>
        <p className="text-sm text-gray-600 mb-6">{error || 'This listing may have been removed.'}</p>
        <button
          onClick={() => navigate('/')}
          className="px-6 py-2.5 bg-gray-900 hover:bg-black text-white rounded-xl text-sm font-semibold"
        >
          Back to Explore
        </button>
      </div>
    );
  }

  const images = listing.images && listing.images.length > 0 ? listing.images : [];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 pb-24">
      {/* Title & Header Section */}
      <div className="mb-6">
        <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-2">{listing.title}</h1>
        
        <div className="flex flex-wrap items-center justify-between text-sm text-gray-600 gap-2">
          <div className="flex items-center space-x-2">
            <span className="flex items-center font-semibold text-gray-900">
              <Star className="w-4 h-4 fill-current mr-1" />
              {listing.rating ? listing.rating.toFixed(2) : '5.0'}
            </span>
            <span>•</span>
            <span className="underline font-medium cursor-pointer">
              {reviews.length} review{reviews.length !== 1 ? 's' : ''}
            </span>
            <span>•</span>
            <span className="flex items-center text-gray-700">
              <MapPin className="w-4 h-4 mr-1 text-gray-400" />
              {listing.location.address}, {listing.location.city}, {listing.location.country}
            </span>
          </div>

          <div className="flex items-center space-x-4">
            <button
              onClick={() => {
                navigator.clipboard.writeText(window.location.href);
                alert('Listing link copied to clipboard!');
              }}
              className="flex items-center space-x-1.5 hover:bg-gray-100 py-1.5 px-3 rounded-lg text-xs font-semibold text-gray-700 underline"
            >
              <Share2 className="w-4 h-4" />
              <span>Share</span>
            </button>
            <button className="flex items-center space-x-1.5 hover:bg-gray-100 py-1.5 px-3 rounded-lg text-xs font-semibold text-gray-700 underline">
              <Heart className="w-4 h-4" />
              <span>Save</span>
            </button>
          </div>
        </div>
      </div>

      {/* Airbnb 5-Photo Collage Grid */}
      <div className="relative rounded-3xl overflow-hidden mb-10 shadow-sm bg-gray-100">
        <div className="grid grid-cols-1 md:grid-cols-4 md:grid-rows-2 gap-2 h-[320px] sm:h-[450px]">
          {/* Main big cover photo */}
          <div
            onClick={() => setIsPhotoModalOpen(true)}
            className="md:col-span-2 md:row-span-2 relative cursor-pointer group overflow-hidden"
          >
            <img
              src={images[0]}
              alt={listing.title}
              className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
            />
          </div>

          {/* 4 secondary photos */}
          {images.slice(1, 5).map((img, idx) => (
            <div
              key={idx}
              onClick={() => setIsPhotoModalOpen(true)}
              className="hidden md:block relative cursor-pointer group overflow-hidden"
            >
              <img
                src={img}
                alt={`${listing.title} photo ${idx + 2}`}
                className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
              />
            </div>
          ))}
        </div>

        {/* View All Photos Button */}
        <button
          onClick={() => setIsPhotoModalOpen(true)}
          className="absolute bottom-4 right-4 bg-white/90 hover:bg-white text-gray-900 border border-gray-900 px-4 py-2 rounded-xl text-xs font-bold shadow-md transition flex items-center space-x-2"
        >
          <span>Show all {images.length} photos</span>
        </button>
      </div>

      {/* Main Layout Grid (Content on Left, Booking Box on Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        
        {/* Left Column (Listing Details) */}
        <div className="lg:col-span-2 space-y-8">
          
          {/* Host & Accommodation Summary */}
          <div className="flex items-center justify-between pb-6 border-b border-gray-200">
            <div>
              <h2 className="text-xl font-bold text-gray-900">
                {listing.roomType} hosted by {listing.host?.name || 'Superhost'}
              </h2>
              <p className="text-sm text-gray-500 mt-1">
                {listing.maxGuests} guests • {listing.bedrooms} bedroom{listing.bedrooms > 1 ? 's' : ''} • {listing.beds} bed{listing.beds > 1 ? 's' : ''} • {listing.bathrooms} bath{listing.bathrooms > 1 ? 's' : ''}
              </p>
            </div>
            <img
              src={
                listing.host?.avatar ||
                'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80'
              }
              alt={listing.host?.name}
              className="w-14 h-14 rounded-full object-cover border border-gray-200 shadow-xs"
            />
          </div>

          {/* Highlights */}
          <div className="space-y-4 pb-6 border-b border-gray-200 text-sm">
            <div className="flex items-start space-x-4">
              <ShieldCheck className="w-6 h-6 text-gray-800 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-gray-900">Dedicated workspace & fast wifi</p>
                <p className="text-xs text-gray-500">A private room with wifi that’s well-suited for working remotely.</p>
              </div>
            </div>
            <div className="flex items-start space-x-4">
              <Sparkles className="w-6 h-6 text-gray-800 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-gray-900">Experienced Superhost</p>
                <p className="text-xs text-gray-500">Superhosts are experienced, highly rated hosts committed to great stays.</p>
              </div>
            </div>
          </div>

          {/* AirCover Guarantee */}
          <div className="pb-6 border-b border-gray-200">
            <div className="flex items-center space-x-1.5 mb-2">
              <span className="text-airbnb font-extrabold text-xl">air</span>
              <span className="text-gray-900 font-extrabold text-xl">cover</span>
            </div>
            <p className="text-xs text-gray-500 leading-relaxed">
              Every booking includes free protection from Host cancellations, listing inaccuracies, and other issues like trouble checking in.
            </p>
          </div>

          {/* Description */}
          <div className="pb-6 border-b border-gray-200">
            <h3 className="text-lg font-bold text-gray-900 mb-3">About this space</h3>
            <p className="text-sm text-gray-700 leading-relaxed whitespace-pre-line">
              {listing.description}
            </p>
          </div>

          {/* Amenities Grid */}
          <div className="pb-6 border-b border-gray-200">
            <h3 className="text-lg font-bold text-gray-900 mb-4">What this place offers</h3>
            <div className="grid grid-cols-2 gap-4 text-sm text-gray-800">
              {listing.amenities && listing.amenities.map((item, index) => {
                const IconComponent = amenityIcons[item] || CheckCircle;
                return (
                  <div key={index} className="flex items-center space-x-3">
                    <IconComponent className="w-5 h-5 text-gray-600" />
                    <span>{item}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Reviews Section */}
          <div className="pt-2 space-y-6">
            <div className="flex items-center space-x-2 text-xl font-bold text-gray-900">
              <Star className="w-5 h-5 fill-current" />
              <span>{listing.rating ? listing.rating.toFixed(2) : '5.0'}</span>
              <span>•</span>
              <span>{reviews.length} Reviews</span>
            </div>

            {/* Submit New Review Form */}
            <div className="p-5 bg-gray-50 border border-gray-200 rounded-2xl">
              <h4 className="font-bold text-sm text-gray-900 mb-2 flex items-center space-x-2">
                <MessageSquare className="w-4 h-4 text-airbnb" />
                <span>Leave a Review</span>
              </h4>

              {reviewMsg && (
                <div className="mb-3 text-xs p-2.5 rounded-lg bg-blue-50 text-blue-700 border border-blue-200">
                  {reviewMsg}
                </div>
              )}

              <form onSubmit={handleReviewSubmit} className="space-y-3">
                <div className="flex items-center space-x-2">
                  <span className="text-xs font-semibold text-gray-700">Rating:</span>
                  <div className="flex space-x-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        type="button"
                        key={star}
                        onClick={() => setReviewRating(star)}
                        className="p-1 text-amber-500 hover:scale-110 transition"
                      >
                        <Star
                          className={`w-5 h-5 ${
                            star <= reviewRating ? 'fill-amber-400 text-amber-400' : 'text-gray-300'
                          }`}
                        />
                      </button>
                    ))}
                  </div>
                </div>

                <textarea
                  rows={3}
                  required
                  placeholder="Share details of your experience, cleanliness, communication, and location..."
                  value={reviewComment}
                  onChange={(e) => setReviewComment(e.target.value)}
                  className="w-full p-3 bg-white border border-gray-300 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-airbnb"
                />

                <div className="flex justify-end">
                  <button
                    type="submit"
                    disabled={reviewSubmitting}
                    className="px-4 py-2 bg-gray-900 hover:bg-black text-white text-xs font-semibold rounded-xl shadow-xs transition disabled:opacity-50"
                  >
                    {reviewSubmitting ? 'Posting...' : 'Submit Review'}
                  </button>
                </div>
              </form>
            </div>

            {/* Reviews List */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
              {reviews.map((rev) => (
                <div key={rev._id} className="space-y-2 border-b md:border-b-0 pb-4 md:pb-0">
                  <div className="flex items-center space-x-3">
                    <img
                      src={
                        rev.user?.avatar ||
                        'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80'
                      }
                      alt={rev.user?.name}
                      className="w-10 h-10 rounded-full object-cover"
                    />
                    <div>
                      <p className="font-semibold text-xs text-gray-900">{rev.user?.name || 'Traveler'}</p>
                      <p className="text-[11px] text-gray-400">
                        {new Date(rev.createdAt).toLocaleDateString('en-US', {
                          month: 'long',
                          year: 'numeric',
                        })}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-1 text-amber-500">
                    {Array.from({ length: rev.rating || 5 }).map((_, i) => (
                      <Star key={i} className="w-3 h-3 fill-current" />
                    ))}
                  </div>
                  <p className="text-xs text-gray-700 leading-relaxed">{rev.comment}</p>
                </div>
              ))}
            </div>

          </div>

        </div>

        {/* Right Column: Sticky Booking Widget */}
        <div className="lg:col-span-1">
          <div className="sticky top-28 bg-white border border-gray-200 rounded-3xl p-6 shadow-xl space-y-5">
            
            {/* Price & Rating Header */}
            <div className="flex items-baseline justify-between">
              <div>
                <span className="text-2xl font-extrabold text-gray-900">${listing.pricePerNight}</span>
                <span className="text-xs text-gray-500 font-normal"> / night</span>
              </div>
              <div className="flex items-center text-xs font-semibold text-gray-900">
                <Star className="w-3.5 h-3.5 fill-current mr-1 text-gray-900" />
                <span>{listing.rating ? listing.rating.toFixed(2) : '5.0'}</span>
                <span className="text-gray-400 mx-1">•</span>
                <span className="underline text-gray-500">{reviews.length} reviews</span>
              </div>
            </div>

            {/* Booking Form */}
            <form onSubmit={handleBooking} className="space-y-4">
              
              {/* Date Pickers Box */}
              <div className="border border-gray-300 rounded-2xl overflow-hidden focus-within:border-gray-900">
                <div className="grid grid-cols-2 divide-x divide-gray-300 border-b border-gray-300">
                  <div className="p-2.5">
                    <label className="block text-[10px] font-bold uppercase text-gray-600">CHECK-IN</label>
                    <input
                      type="date"
                      required
                      min={new Date().toISOString().split('T')[0]}
                      value={checkIn}
                      onChange={(e) => setCheckIn(e.target.value)}
                      className="w-full text-xs font-medium focus:outline-none bg-transparent pt-1"
                    />
                  </div>
                  <div className="p-2.5">
                    <label className="block text-[10px] font-bold uppercase text-gray-600">CHECKOUT</label>
                    <input
                      type="date"
                      required
                      min={checkIn || new Date().toISOString().split('T')[0]}
                      value={checkOut}
                      onChange={(e) => setCheckOut(e.target.value)}
                      className="w-full text-xs font-medium focus:outline-none bg-transparent pt-1"
                    />
                  </div>
                </div>

                {/* Guests count */}
                <div className="p-2.5">
                  <label className="block text-[10px] font-bold uppercase text-gray-600">GUESTS</label>
                  <select
                    value={guests}
                    onChange={(e) => setGuests(Number(e.target.value))}
                    className="w-full text-xs font-medium focus:outline-none bg-transparent pt-1"
                  >
                    {Array.from({ length: listing.maxGuests || 4 }).map((_, i) => (
                      <option key={i + 1} value={i + 1}>
                        {i + 1} guest{i > 0 ? 's' : ''}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Booking Error Notice */}
              {bookingError && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 text-xs flex items-center space-x-2">
                  <AlertCircle className="w-4 h-4 flex-shrink-0" />
                  <span>{bookingError}</span>
                </div>
              )}

              {/* Booking Success Notice */}
              {bookingSuccess && (
                <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-xs flex items-center space-x-2 font-semibold animate-bounce">
                  <CheckCircle className="w-4 h-4 flex-shrink-0 text-emerald-600" />
                  <span>Reservation confirmed! Redirecting to your trips...</span>
                </div>
              )}

              {/* Reserve Button */}
              <button
                type="submit"
                disabled={bookingLoading || bookingSuccess}
                className="w-full py-3.5 bg-gradient-to-r from-airbnb to-airbnb-dark hover:opacity-95 text-white font-bold rounded-2xl text-sm shadow-md transition transform active:scale-95 disabled:opacity-50"
              >
                {bookingLoading
                  ? 'Reserving stay...'
                  : bookingSuccess
                  ? 'Booked!'
                  : 'Reserve'}
              </button>

              <p className="text-center text-[11px] text-gray-500">You won't be charged yet</p>

              {/* Price Calculation Breakdown */}
              {nights > 0 && (
                <div className="space-y-2 pt-3 border-t border-gray-200 text-xs text-gray-700">
                  <div className="flex justify-between">
                    <span className="underline">
                      ${listing.pricePerNight} x {nights} night{nights > 1 ? 's' : ''}
                    </span>
                    <span>${basePrice}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="underline">Cleaning fee</span>
                    <span>${cleaningFee}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="underline">Airbnb service fee</span>
                    <span>${serviceFee}</span>
                  </div>
                  <div className="flex justify-between pt-3 border-t border-gray-200 font-extrabold text-sm text-gray-900">
                    <span>Total before taxes</span>
                    <span>${totalPrice}</span>
                  </div>
                </div>
              )}

            </form>

          </div>
        </div>

      </div>

      {/* Full Photo Gallery Modal */}
      {isPhotoModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/95 flex flex-col p-4 sm:p-8 animate-in fade-in duration-200">
          <div className="flex justify-between items-center text-white pb-4">
            <h3 className="font-bold text-sm sm:text-base">{listing.title} Photos</h3>
            <button
              onClick={() => setIsPhotoModalOpen(false)}
              className="p-2 bg-white/10 hover:bg-white/20 rounded-full transition"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
          <div className="flex-1 overflow-y-auto max-w-4xl mx-auto w-full space-y-6 py-4">
            {images.map((img, idx) => (
              <img
                key={idx}
                src={img}
                alt={`${listing.title} full photo ${idx + 1}`}
                className="w-full rounded-2xl object-cover shadow-2xl"
              />
            ))}
          </div>
        </div>
      )}

    </div>
  );
};

export default ListingDetailPage;
