import React from 'react';
import {
  Palmtree,
  Tent,
  Building2,
  Waves,
  Castle,
  Trees,
  Home,
  Flame,
  Mountain,
  SlidersHorizontal,
  Compass,
} from 'lucide-react';

export const categories = [
  { id: 'All', label: 'All Homes', icon: Compass },
  { id: 'Beachfront', label: 'Beachfront', icon: Palmtree },
  { id: 'Cabins', label: 'Cabins', icon: Trees },
  { id: 'Iconic Cities', label: 'Iconic Cities', icon: Building2 },
  { id: 'Lakefront', label: 'Lakefront', icon: Waves },
  { id: 'Mansions', label: 'Mansions', icon: Castle },
  { id: 'Countryside', label: 'Countryside', icon: Home },
  { id: 'Tiny Homes', label: 'Tiny Homes', icon: Home },
  { id: 'Trending', label: 'Trending', icon: Flame },
  { id: 'Mountains', label: 'Mountains', icon: Mountain },
  { id: 'Camping', label: 'Camping', icon: Tent },
];

const CategoriesBar = ({ activeCategory, onSelectCategory, onOpenFilters, activeFiltersCount }) => {
  return (
    <div className="bg-white border-b border-gray-200 sticky top-20 z-30 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between gap-4 py-3">
        
        {/* Categories scroll area */}
        <div className="flex items-center space-x-6 overflow-x-auto no-scrollbar scroll-smooth flex-1 py-1">
          {categories.map((cat) => {
            const Icon = cat.icon;
            const isSelected = activeCategory === cat.id;

            return (
              <button
                key={cat.id}
                onClick={() => onSelectCategory(cat.id)}
                className={`flex flex-col items-center justify-center space-y-1.5 pb-2 border-b-2 transition whitespace-nowrap group flex-shrink-0 min-w-[56px] ${
                  isSelected
                    ? 'border-gray-900 text-gray-900 font-semibold'
                    : 'border-transparent text-gray-500 hover:text-gray-800 hover:border-gray-300'
                }`}
              >
                <Icon
                  className={`w-6 h-6 transition transform group-hover:scale-105 ${
                    isSelected ? 'text-gray-900 stroke-[2.2]' : 'text-gray-500'
                  }`}
                />
                <span className="text-xs">{cat.label}</span>
              </button>
            );
          })}
        </div>

        {/* Filters button on the right */}
        <button
          onClick={onOpenFilters}
          className="flex items-center space-x-2 border border-gray-300 hover:border-gray-900 rounded-xl px-4 py-2.5 text-xs font-semibold text-gray-800 hover:bg-gray-50 transition flex-shrink-0 shadow-xs"
        >
          <SlidersHorizontal className="w-4 h-4" />
          <span>Filters</span>
          {activeFiltersCount > 0 && (
            <span className="bg-airbnb text-white rounded-full w-5 h-5 flex items-center justify-center text-[10px] font-bold">
              {activeFiltersCount}
            </span>
          )}
        </button>

      </div>
    </div>
  );
};

export default CategoriesBar;
