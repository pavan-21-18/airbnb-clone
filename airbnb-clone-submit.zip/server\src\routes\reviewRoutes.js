const express = require('express');
const router = express.Router();
const {
  createReview,
  getListingReviews,
} = require('../controllers/reviewController');
const { protect } = require('../middleware/authMiddleware');

router.get('/listing/:listingId', getListingReviews);
router.post('/', protect, createReview);

module.exports = router;
