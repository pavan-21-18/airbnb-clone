import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Upload,
  Plus,
  Trash2,
  DollarSign,
  MapPin,
  Check,
  AlertCircle,
  ArrowLeft,
} from 'lucide-react';
import { listingApi } from '../api/listingApi';
import { useAuth } from '../context/AuthContext';

const categoriesList = [
  'Beachfront',
  'Cabins',
  'Iconic Cities',
  'Lakefront',
  'Mansions',
  'Countryside',
  'Tiny Homes',
  'Trending',
  'Mountains',
  'Camping',
  'Villas',
];

const propertyTypes = ['Apartment', 'House', 'Villa', 'Cabin', 'Studio', 'Condo', 'Cottage'];
const roomTypes = ['Entire place', 'Private room', 'Shared room'];

const allAmenities = [
  'Wifi',
  'Kitchen',
  'Air conditioning',
  'Free parking',
  'Pool',
  'Hot tub',
  'TV',
  'Dedicated workspace',
  'EV charger',
  'Ocean view',
  'Mountain view',
  'BBQ grill',
  'Pets allowed',
  'Washer',
  'Gym',
];

const EditListingPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();

  const [loading, setLoading] = useState(true);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('Beachfront');
  const [propertyType, setPropertyType] = useState('Apartment');
  const [roomType, setRoomType] = useState('Entire place');

  // Location
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('');
  const [country, setCountry] = useState('');
  const [zipCode, setZipCode] = useState('');

  // Capacity & Pricing
  const [maxGuests, setMaxGuests] = useState(2);
  const [bedrooms, setBedrooms] = useState(1);
  const [beds, setBeds] = useState(1);
  const [bathrooms, setBathrooms] = useState(1);
  const [pricePerNight, setPricePerNight] = useState(150);
  const [cleaningFee, setCleaningFee] = useState(40);

  // Amenities & Images
  const [amenities, setAmenities] = useState([]);
  const [images, setImages] = useState([]);
  const [customImageUrl, setCustomImageUrl] = useState('');
  const [uploading, setUploading] = useState(false);

  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    const fetchListing = async () => {
      try {
        const res = await listingApi.getById(id);
        if (res.success && res.listing) {
          const l = res.listing;
          setTitle(l.title);
          setDescription(l.description);
          setCategory(l.category);
          setPropertyType(l.propertyType);
          setRoomType(l.roomType);
          setAddress(l.location?.address || '');
          setCity(l.location?.city || '');
          setState(l.location?.state || '');
          setCountry(l.location?.country || '');
          setZipCode(l.location?.zipCode || '');
          setMaxGuests(l.maxGuests || 2);
          setBedrooms(l.bedrooms || 1);
          setBeds(l.beds || 1);
          setBathrooms(l.bathrooms || 1);
          setPricePerNight(l.pricePerNight || 100);
          setCleaningFee(l.cleaningFee || 40);
          setAmenities(l.amenities || []);
          setImages(l.images || []);
        }
      } catch (err) {
        setError(err.response?.data?.message || 'Failed to load listing for editing');
      } finally {
        setLoading(false);
      }
    };

    fetchListing();
  }, [id]);

  const toggleAmenity = (item) => {
    if (amenities.includes(item)) {
      setAmenities(amenities.filter((a) => a !== item));
    } else {
      setAmenities([...amenities, item]);
    }
  };

  const handleFileUpload = async (e) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const formData = new FormData();
    for (let i = 0; i < files.length; i++) {
      formData.append('images', files[i]);
    }

    setUploading(true);
    setError('');
    try {
      const res = await listingApi.uploadImages(formData);
      if (res.success && res.images) {
        setImages((prev) => [...prev, ...res.images]);
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to upload photo(s).');
    } finally {
      setUploading(false);
    }
  };

  const addImageUrl = () => {
    if (!customImageUrl.trim()) return;
    setImages((prev) => [...prev, customImageUrl.trim()]);
    setCustomImageUrl('');
  };

  const removeImage = (index) => {
    setImages(images.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    if (images.length === 0) {
      setError('Please provide at least one photo.');
      return;
    }

    setSubmitting(true);
    try {
      const payload = {
        title,
        description,
        category,
        propertyType,
        roomType,
        location: {
          address,
          city,
          state,
          country,
          zipCode,
        },
        pricePerNight: Number(pricePerNight),
        cleaningFee: Number(cleaningFee),
        maxGuests: Number(maxGuests),
        bedrooms: Number(bedrooms),
        beds: Number(beds),
        bathrooms: Number(bathrooms),
        amenities,
        images,
      };

      const res = await listingApi.update(id, payload);
      if (res.success) {
        navigate(`/listings/${id}`);
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to update listing.');
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-12 animate-pulse space-y-6">
        <div className="h-8 bg-gray-200 rounded w-1/3"></div>
        <div className="h-64 bg-gray-200 rounded-3xl"></div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 pb-24">
      <button
        onClick={() => navigate('/dashboard?tab=listings')}
        className="flex items-center space-x-2 text-xs font-semibold text-gray-600 hover:text-gray-900 mb-6 transition"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back to my listings</span>
      </button>

      <div className="mb-8">
        <h1 className="text-3xl font-extrabold text-gray-900">Edit Property Details</h1>
        <p className="text-sm text-gray-500 mt-1">Update your listing information, pricing, photos, or amenities.</p>
      </div>

      {error && (
        <div className="mb-6 p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center space-x-2 font-medium">
          <AlertCircle className="w-5 h-5 flex-shrink-0" />
          <span>{error}</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-8">
        {/* Overview */}
        <div className="bg-white border border-gray-200 rounded-3xl p-6 sm:p-8 space-y-6 shadow-xs">
          <h2 className="text-lg font-bold text-gray-900 border-b border-gray-100 pb-3">Property Overview</h2>
          
          <div>
            <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Title</label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl text-sm font-medium focus:bg-white focus:outline-none focus:ring-2 focus:ring-airbnb"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Description</label>
            <textarea
              rows={4}
              required
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:bg-white focus:outline-none focus:ring-2 focus:ring-airbnb"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-airbnb"
              >
                {categoriesList.map((cat) => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Property Type</label>
              <select
                value={propertyType}
                onChange={(e) => setPropertyType(e.target.value)}
                className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-airbnb"
              >
                {propertyTypes.map((t) => (
                  <option key={t} value={t}>{t}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Room Type</label>
              <select
                value={roomType}
                onChange={(e) => setRoomType(e.target.value)}
                className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-airbnb"
              >
                {roomTypes.map((rt) => (
                  <option key={rt} value={rt}>{rt}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Location */}
        <div className="bg-white border border-gray-200 rounded-3xl p-6 sm:p-8 space-y-6 shadow-xs">
          <h2 className="text-lg font-bold text-gray-900 border-b border-gray-100 pb-3 flex items-center space-x-2">
            <MapPin className="w-5 h-5 text-airbnb" />
            <span>Location</span>
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Address</label>
              <input
                type="text"
                required
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-airbnb"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 uppercase mb-1">City</label>
              <input
                type="text"
                required
                value={city}
                onChange={(e) => setCity(e.target.value)}
                className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-airbnb"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Country</label>
              <input
                type="text"
                required
                value={country}
                onChange={(e) => setCountry(e.target.value)}
                className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-airbnb"
              />
            </div>
          </div>
        </div>

        {/* Pricing & Capacity */}
        <div className="bg-white border border-gray-200 rounded-3xl p-6 sm:p-8 space-y-6 shadow-xs">
          <h2 className="text-lg font-bold text-gray-900 border-b border-gray-100 pb-3 flex items-center space-x-2">
            <DollarSign className="w-5 h-5 text-airbnb" />
            <span>Pricing & Capacity</span>
          </h2>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div>
              <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Max Guests</label>
              <input
                type="number"
                min={1}
                required
                value={maxGuests}
                onChange={(e) => setMaxGuests(Number(e.target.value))}
                className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl text-sm font-semibold"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Price / Night ($)</label>
              <input
                type="number"
                min={1}
                required
                value={pricePerNight}
                onChange={(e) => setPricePerNight(Number(e.target.value))}
                className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl text-sm font-bold text-gray-900"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Bedrooms</label>
              <input
                type="number"
                min={1}
                required
                value={bedrooms}
                onChange={(e) => setBedrooms(Number(e.target.value))}
                className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl text-sm font-semibold"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Bathrooms</label>
              <input
                type="number"
                min={1}
                required
                value={bathrooms}
                onChange={(e) => setBathrooms(Number(e.target.value))}
                className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl text-sm font-semibold"
              />
            </div>
          </div>
        </div>

        {/* Photos */}
        <div className="bg-white border border-gray-200 rounded-3xl p-6 sm:p-8 space-y-6 shadow-xs">
          <h2 className="text-lg font-bold text-gray-900 border-b border-gray-100 pb-3 flex items-center space-x-2">
            <Upload className="w-5 h-5 text-airbnb" />
            <span>Photos</span>
          </h2>

          <div className="flex items-center space-x-2">
            <input
              type="url"
              placeholder="Add photo web link (Unsplash or direct image URL)"
              value={customImageUrl}
              onChange={(e) => setCustomImageUrl(e.target.value)}
              className="flex-1 p-3 bg-gray-50 border border-gray-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-airbnb"
            />
            <button
              type="button"
              onClick={addImageUrl}
              className="px-4 py-3 bg-gray-100 hover:bg-gray-200 text-gray-800 rounded-xl text-xs font-bold transition flex items-center space-x-1"
            >
              <Plus className="w-4 h-4" />
              <span>Add</span>
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {images.map((img, idx) => (
              <div key={idx} className="relative aspect-video rounded-xl overflow-hidden group border border-gray-200">
                <img src={img} alt="Property" className="w-full h-full object-cover" />
                <button
                  type="button"
                  onClick={() => removeImage(idx)}
                  className="absolute top-1.5 right-1.5 bg-black/70 hover:bg-rose-600 text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Actions */}
        <div className="flex justify-end space-x-4">
          <button
            type="button"
            onClick={() => navigate('/dashboard?tab=listings')}
            className="px-6 py-3 rounded-full text-sm font-semibold text-gray-600 hover:bg-gray-100 transition"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={submitting}
            className="px-8 py-3.5 bg-gray-900 hover:bg-black text-white font-bold rounded-full text-sm shadow-md transition disabled:opacity-50"
          >
            {submitting ? 'Saving Changes...' : 'Save Updates'}
          </button>
        </div>
      </form>
    </div>
  );
};

export default EditListingPage;
