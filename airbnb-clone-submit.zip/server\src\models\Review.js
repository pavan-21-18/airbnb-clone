const mongoose = require('mongoose');

const reviewSchema = new mongoose.Schema(
  {
    listing: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Listing',
      required: true,
    },
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    rating: {
      type: Number,
      required: [true, 'Rating is required'],
      min: 1,
      max: 5,
    },
    cleanliness: { type: Number, default: 5, min: 1, max: 5 },
    accuracy: { type: Number, default: 5, min: 1, max: 5 },
    communication: { type: Number, default: 5, min: 1, max: 5 },
    location: { type: Number, default: 5, min: 1, max: 5 },
    value: { type: Number, default: 5, min: 1, max: 5 },
    comment: {
      type: String,
      required: [true, 'Comment cannot be empty'],
      maxlength: [1000, 'Comment cannot exceed 1000 characters'],
    },
  },
  {
    timestamps: true,
  }
);

// Prevent user from leaving duplicate reviews on same listing
reviewSchema.index({ listing: 1, user: 1 }, { unique: true });

// Static method to recalculate average rating of listing
reviewSchema.statics.calculateAverageRating = async function (listingId) {
  const stats = await this.aggregate([
    { $match: { listing: listingId } },
    {
      $group: {
        _id: '$listing',
        numReviews: { $sum: 1 },
        avgRating: { $avg: '$rating' },
      },
    },
  ]);

  try {
    const Listing = mongoose.model('Listing');
    if (stats.length > 0) {
      await Listing.findByIdAndUpdate(listingId, {
        rating: Math.round(stats[0].avgRating * 10) / 10,
        numReviews: stats[0].numReviews,
      });
    } else {
      await Listing.findByIdAndUpdate(listingId, {
        rating: 5.0,
        numReviews: 0,
      });
    }
  } catch (err) {
    console.error('Error updating listing rating:', err);
  }
};

reviewSchema.post('save', async function () {
  await this.constructor.calculateAverageRating(this.listing);
});

reviewSchema.post('findOneAndDelete', async function (doc) {
  if (doc) {
    await doc.constructor.calculateAverageRating(doc.listing);
  }
});

const Review = mongoose.model('Review', reviewSchema);
module.exports = Review;
