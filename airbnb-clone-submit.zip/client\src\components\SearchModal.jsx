import React, { useState } from 'react';
import { X, Search, MapPin, Calendar, Users, Sparkles } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const quickDestinations = [
  { name: "I'm flexible", icon: Sparkles, query: '' },
  { name: 'Malibu, USA', icon: MapPin, query: 'Malibu' },
  { name: 'New York, USA', icon: MapPin, query: 'New York' },
  { name: 'Paris, France', icon: MapPin, query: 'Paris' },
  { name: 'Santorini, Greece', icon: MapPin, query: 'Santorini' },
  { name: 'Kyoto, Japan', icon: MapPin, query: 'Kyoto' },
];

const SearchModal = ({ isOpen, onClose }) => {
  const navigate = useNavigate();
  const [destination, setDestination] = useState('');
  const [checkIn, setCheckIn] = useState('');
  const [checkOut, setCheckOut] = useState('');
  const [guests, setGuests] = useState(1);

  if (!isOpen) return null;

  const handleSearch = (e) => {
    e.preventDefault();
    const params = new URLSearchParams();
    if (destination.trim()) params.append('search', destination.trim());
    if (guests > 1) params.append('guests', guests.toString());
    if (checkIn) params.append('checkIn', checkIn);
    if (checkOut) params.append('checkOut', checkOut);

    onClose();
    navigate(`/?${params.toString()}`);
  };

  const selectQuickDest = (query) => {
    setDestination(query);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-12 sm:pt-20 px-4 bg-black/40 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-2xl w-full p-6 shadow-2xl relative border border-gray-100">
        
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full hover:bg-gray-100 text-gray-500 hover:text-gray-900 transition"
        >
          <X className="w-5 h-5" />
        </button>

        <h2 className="text-xl font-bold text-gray-900 mb-6">Search places to stay</h2>

        <form onSubmit={handleSearch} className="space-y-5">
          {/* Destination Input */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-gray-700 mb-1.5">
              Where to?
            </label>
            <div className="relative">
              <MapPin className="absolute left-3.5 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search destinations (e.g. Malibu, Paris, Aspen)"
                value={destination}
                onChange={(e) => setDestination(e.target.value)}
                className="w-full pl-11 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-2xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-airbnb text-sm font-medium"
                autoFocus
              />
            </div>

            {/* Quick destination tags */}
            <div className="mt-3 flex flex-wrap gap-2">
              {quickDestinations.map((dest, i) => {
                const Icon = dest.icon;
                return (
                  <button
                    key={i}
                    type="button"
                    onClick={() => selectQuickDest(dest.query)}
                    className="flex items-center space-x-1.5 px-3 py-1.5 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-full text-xs font-medium transition"
                  >
                    <Icon className="w-3.5 h-3.5 text-gray-500" />
                    <span>{dest.name}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Dates Selection */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-gray-700 mb-1.5">
                Check in
              </label>
              <div className="relative">
                <Calendar className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type="date"
                  value={checkIn}
                  onChange={(e) => setCheckIn(e.target.value)}
                  className="w-full pl-10 pr-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-airbnb text-sm"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-gray-700 mb-1.5">
                Check out
              </label>
              <div className="relative">
                <Calendar className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type="date"
                  value={checkOut}
                  onChange={(e) => setCheckOut(e.target.value)}
                  className="w-full pl-10 pr-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-airbnb text-sm"
                />
              </div>
            </div>
          </div>

          {/* Guests Count */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-gray-700 mb-1.5">
              Who's coming?
            </label>
            <div className="flex items-center justify-between p-3.5 bg-gray-50 border border-gray-200 rounded-2xl">
              <div className="flex items-center space-x-3">
                <Users className="w-5 h-5 text-gray-400" />
                <div>
                  <p className="text-sm font-semibold text-gray-900">Guests</p>
                  <p className="text-xs text-gray-500">Ages 13 or above</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <button
                  type="button"
                  disabled={guests <= 1}
                  onClick={() => setGuests(guests - 1)}
                  className="w-8 h-8 rounded-full border border-gray-300 flex items-center justify-center font-bold text-gray-600 hover:border-gray-900 disabled:opacity-40 transition"
                >
                  -
                </button>
                <span className="text-sm font-bold text-gray-900 w-4 text-center">
                  {guests}
                </span>
                <button
                  type="button"
                  disabled={guests >= 16}
                  onClick={() => setGuests(guests + 1)}
                  className="w-8 h-8 rounded-full border border-gray-300 flex items-center justify-center font-bold text-gray-600 hover:border-gray-900 transition"
                >
                  +
                </button>
              </div>
            </div>
          </div>

          {/* Submit Search Button */}
          <div className="pt-2 flex items-center justify-end space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 text-sm font-semibold text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-full transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-airbnb to-airbnb-dark text-white rounded-full font-semibold text-sm shadow-md hover:shadow-lg transition transform active:scale-95"
            >
              <Search className="w-4 h-4 stroke-[2.5]" />
              <span>Search Properties</span>
            </button>
          </div>
        </form>

      </div>
    </div>
  );
};

export default SearchModal;
