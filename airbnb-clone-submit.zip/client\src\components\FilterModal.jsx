import React, { useState } from 'react';
import { X, Check } from 'lucide-react';

const amenityOptions = [
  'Wifi',
  'Kitchen',
  'Pool',
  'Hot tub',
  'Free parking',
  'Air conditioning',
  'Dedicated workspace',
  'EV charger',
  'Ocean view',
  'Mountain view',
  'BBQ grill',
  'Pets allowed',
  'Washer',
  'Gym',
];

const propertyTypes = ['Any', 'Apartment', 'House', 'Villa', 'Cabin', 'Cottage'];

const FilterModal = ({ isOpen, onClose, filters, onApplyFilters, onClearFilters }) => {
  const [minPrice, setMinPrice] = useState(filters.minPrice || '');
  const [maxPrice, setMaxPrice] = useState(filters.maxPrice || '');
  const [propertyType, setPropertyType] = useState(filters.propertyType || 'Any');
  const [bedrooms, setBedrooms] = useState(filters.bedrooms || '');
  const [bathrooms, setBathrooms] = useState(filters.bathrooms || '');
  const [sort, setSort] = useState(filters.sort || '');
  const [selectedAmenities, setSelectedAmenities] = useState(filters.amenities || []);

  if (!isOpen) return null;

  const toggleAmenity = (item) => {
    if (selectedAmenities.includes(item)) {
      setSelectedAmenities(selectedAmenities.filter((a) => a !== item));
    } else {
      setSelectedAmenities([...selectedAmenities, item]);
    }
  };

  const handleApply = () => {
    onApplyFilters({
      minPrice: minPrice ? Number(minPrice) : '',
      maxPrice: maxPrice ? Number(maxPrice) : '',
      propertyType: propertyType === 'Any' ? '' : propertyType,
      bedrooms: bedrooms ? Number(bedrooms) : '',
      bathrooms: bathrooms ? Number(bathrooms) : '',
      sort,
      amenities: selectedAmenities,
    });
    onClose();
  };

  const handleClear = () => {
    setMinPrice('');
    setMaxPrice('');
    setPropertyType('Any');
    setBedrooms('');
    setBathrooms('');
    setSort('');
    setSelectedAmenities([]);
    onClearFilters();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-2xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden border border-gray-100">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-gray-100 text-gray-500 hover:text-gray-900 transition"
          >
            <X className="w-5 h-5" />
          </button>
          <h3 className="font-bold text-gray-900 text-base">Filters</h3>
          <div className="w-9" /> {/* balance spacing */}
        </div>

        {/* Scrollable Content */}
        <div className="p-6 overflow-y-auto space-y-7 flex-1">
          
          {/* Price Range */}
          <div>
            <h4 className="font-semibold text-gray-900 text-base mb-1">Price range</h4>
            <p className="text-xs text-gray-500 mb-4">Nightly prices before taxes and fees</p>
            <div className="flex items-center space-x-4">
              <div className="flex-1 border border-gray-300 rounded-2xl p-3 focus-within:border-gray-900">
                <span className="block text-[11px] font-semibold text-gray-500 uppercase">Minimum</span>
                <div className="flex items-center text-sm font-semibold">
                  <span className="mr-1">$</span>
                  <input
                    type="number"
                    value={minPrice}
                    onChange={(e) => setMinPrice(e.target.value)}
                    placeholder="50"
                    className="w-full focus:outline-none"
                  />
                </div>
              </div>
              <span className="text-gray-400 font-bold">-</span>
              <div className="flex-1 border border-gray-300 rounded-2xl p-3 focus-within:border-gray-900">
                <span className="block text-[11px] font-semibold text-gray-500 uppercase">Maximum</span>
                <div className="flex items-center text-sm font-semibold">
                  <span className="mr-1">$</span>
                  <input
                    type="number"
                    value={maxPrice}
                    onChange={(e) => setMaxPrice(e.target.value)}
                    placeholder="1000"
                    className="w-full focus:outline-none"
                  />
                </div>
              </div>
            </div>
          </div>

          <hr className="border-gray-200" />

          {/* Sort By */}
          <div>
            <h4 className="font-semibold text-gray-900 text-base mb-3">Sort by</h4>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {[
                { id: '', label: 'Default' },
                { id: 'rating', label: 'Top Rated' },
                { id: 'price_asc', label: 'Price: Low' },
                { id: 'price_desc', label: 'Price: High' },
              ].map((opt) => (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => setSort(opt.id)}
                  className={`py-2 px-3 text-xs font-semibold rounded-xl border transition ${
                    sort === opt.id
                      ? 'border-gray-900 bg-gray-900 text-white'
                      : 'border-gray-200 hover:border-gray-900 text-gray-700'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          <hr className="border-gray-200" />

          {/* Property Type */}
          <div>
            <h4 className="font-semibold text-gray-900 text-base mb-3">Property type</h4>
            <div className="flex flex-wrap gap-2">
              {propertyTypes.map((type) => (
                <button
                  key={type}
                  type="button"
                  onClick={() => setPropertyType(type)}
                  className={`py-2 px-4 text-xs font-semibold rounded-full border transition ${
                    propertyType === type
                      ? 'border-gray-900 bg-gray-900 text-white'
                      : 'border-gray-200 hover:border-gray-900 text-gray-700'
                  }`}
                >
                  {type}
                </button>
              ))}
            </div>
          </div>

          <hr className="border-gray-200" />

          {/* Bedrooms & Bathrooms */}
          <div>
            <h4 className="font-semibold text-gray-900 text-base mb-3">Rooms and beds</h4>
            
            <div className="space-y-4">
              <div>
                <span className="block text-xs font-medium text-gray-600 mb-2">Bedrooms</span>
                <div className="flex space-x-2">
                  {['', '1', '2', '3', '4'].map((val) => (
                    <button
                      key={val}
                      type="button"
                      onClick={() => setBedrooms(val)}
                      className={`flex-1 py-2 rounded-xl text-xs font-semibold border transition ${
                        bedrooms === val
                          ? 'border-gray-900 bg-gray-900 text-white'
                          : 'border-gray-200 hover:border-gray-900 text-gray-700'
                      }`}
                    >
                      {val === '' ? 'Any' : `${val}+`}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <span className="block text-xs font-medium text-gray-600 mb-2">Bathrooms</span>
                <div className="flex space-x-2">
                  {['', '1', '2', '3'].map((val) => (
                    <button
                      key={val}
                      type="button"
                      onClick={() => setBathrooms(val)}
                      className={`flex-1 py-2 rounded-xl text-xs font-semibold border transition ${
                        bathrooms === val
                          ? 'border-gray-900 bg-gray-900 text-white'
                          : 'border-gray-200 hover:border-gray-900 text-gray-700'
                      }`}
                    >
                      {val === '' ? 'Any' : `${val}+`}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <hr className="border-gray-200" />

          {/* Amenities */}
          <div>
            <h4 className="font-semibold text-gray-900 text-base mb-3">Amenities</h4>
            <div className="grid grid-cols-2 gap-3">
              {amenityOptions.map((amenity) => {
                const isChecked = selectedAmenities.includes(amenity);
                return (
                  <button
                    key={amenity}
                    type="button"
                    onClick={() => toggleAmenity(amenity)}
                    className={`flex items-center space-x-2.5 p-2.5 rounded-xl border text-xs text-left transition ${
                      isChecked
                        ? 'border-gray-900 bg-gray-50 text-gray-900 font-semibold'
                        : 'border-gray-200 text-gray-700 hover:border-gray-400'
                    }`}
                  >
                    <div
                      className={`w-4 h-4 rounded border flex items-center justify-center transition ${
                        isChecked ? 'bg-airbnb border-airbnb text-white' : 'border-gray-300'
                      }`}
                    >
                      {isChecked && <Check className="w-3 h-3 stroke-[3]" />}
                    </div>
                    <span>{amenity}</span>
                  </button>
                );
              })}
            </div>
          </div>

        </div>

        {/* Footer Actions */}
        <div className="px-6 py-4 border-t border-gray-200 flex items-center justify-between bg-white">
          <button
            onClick={handleClear}
            className="text-sm font-bold text-gray-800 underline hover:text-black transition"
          >
            Clear all
          </button>
          <button
            onClick={handleApply}
            className="px-6 py-3 bg-gray-900 hover:bg-black text-white text-sm font-semibold rounded-xl shadow-md transition transform active:scale-95"
          >
            Apply Filters
          </button>
        </div>

      </div>
    </div>
  );
};

export default FilterModal;
