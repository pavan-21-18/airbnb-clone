import axiosInstance from './axiosInstance';

export const reviewApi = {
  create: async (reviewData) => {
    const response = await axiosInstance.post('/reviews', reviewData);
    return response.data;
  },

  getByListing: async (listingId) => {
    const response = await axiosInstance.get(`/reviews/listing/${listingId}`);
    return response.data;
  },
};
