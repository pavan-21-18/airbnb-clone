const Listing = require('../models/Listing');
const User = require('../models/User');

// @desc    Get all listings with search, category & filters
// @route   GET /api/listings
// @access  Public
const getAllListings = async (req, res) => {
  try {
    const {
      search,
      category,
      propertyType,
      minPrice,
      maxPrice,
      guests,
      bedrooms,
      bathrooms,
      amenities,
      sort,
      page = 1,
      limit = 24,
    } = req.query;

    const query = {};

    // Category filter
    if (category && category !== 'All') {
      query.category = category;
    }

    // Property Type filter
    if (propertyType) {
      query.propertyType = propertyType;
    }

    // Keyword Search (Destination / Location / Title)
    if (search) {
      const regex = new RegExp(search, 'i');
      query.$or = [
        { 'location.city': regex },
        { 'location.country': regex },
        { 'location.state': regex },
        { 'location.address': regex },
        { title: regex },
        { description: regex },
      ];
    }

    // Price range filter
    if (minPrice || maxPrice) {
      query.pricePerNight = {};
      if (minPrice) query.pricePerNight.$gte = Number(minPrice);
      if (maxPrice) query.pricePerNight.$lte = Number(maxPrice);
    }

    // Capacity filters
    if (guests) {
      query.maxGuests = { $gte: Number(guests) };
    }
    if (bedrooms) {
      query.bedrooms = { $gte: Number(bedrooms) };
    }
    if (bathrooms) {
      query.bathrooms = { $gte: Number(bathrooms) };
    }

    // Amenities filter
    if (amenities) {
      const amenitiesList = Array.isArray(amenities) ? amenities : amenities.split(',');
      query.amenities = { $all: amenitiesList };
    }

    // Sorting options
    let sortOption = { createdAt: -1 }; // default newest
    if (sort === 'price_asc') sortOption = { pricePerNight: 1 };
    if (sort === 'price_desc') sortOption = { pricePerNight: -1 };
    if (sort === 'rating') sortOption = { rating: -1, numReviews: -1 };

    const pageNum = Number(page);
    const limitNum = Number(limit);
    const skip = (pageNum - 1) * limitNum;

    const total = await Listing.countDocuments(query);
    const listings = await Listing.find(query)
      .populate('host', 'name avatar')
      .sort(sortOption)
      .skip(skip)
      .limit(limitNum);

    res.json({
      success: true,
      count: listings.length,
      total,
      page: pageNum,
      pages: Math.ceil(total / limitNum),
      listings,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get single listing by ID
// @route   GET /api/listings/:id
// @access  Public
const getListingById = async (req, res) => {
  try {
    const listing = await Listing.findById(req.params.id).populate('host', 'name email avatar bio phone createdAt');

    if (!listing) {
      return res.status(404).json({ success: false, message: 'Listing not found' });
    }

    res.json({
      success: true,
      listing,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Create a new listing
// @route   POST /api/listings
// @access  Private (Host/User)
const createListing = async (req, res) => {
  try {
    const {
      title,
      description,
      category,
      propertyType,
      roomType,
      location,
      pricePerNight,
      cleaningFee,
      serviceFee,
      maxGuests,
      bedrooms,
      beds,
      bathrooms,
      amenities,
      images,
    } = req.body;

    if (!title || !description || !pricePerNight || !location || !images || images.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'Please provide all required fields including title, description, location, price, and photos.',
      });
    }

    const listing = new Listing({
      title,
      description,
      category: category || 'Beachfront',
      propertyType: propertyType || 'Apartment',
      roomType: roomType || 'Entire place',
      location,
      pricePerNight: Number(pricePerNight),
      cleaningFee: cleaningFee !== undefined ? Number(cleaningFee) : 40,
      serviceFee: serviceFee !== undefined ? Number(serviceFee) : 25,
      maxGuests: Number(maxGuests) || 2,
      bedrooms: Number(bedrooms) || 1,
      beds: Number(beds) || 1,
      bathrooms: Number(bathrooms) || 1,
      amenities: amenities || [],
      images,
      host: req.user._id,
    });

    const savedListing = await listing.save();

    // Promote user to host role if they weren't already
    if (req.user.role === 'user') {
      await User.findByIdAndUpdate(req.user._id, { role: 'host' });
    }

    res.status(201).json({
      success: true,
      message: 'Listing created successfully',
      listing: savedListing,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Update listing
// @route   PUT /api/listings/:id
// @access  Private (Owner/Admin)
const updateListing = async (req, res) => {
  try {
    let listing = await Listing.findById(req.params.id);

    if (!listing) {
      return res.status(404).json({ success: false, message: 'Listing not found' });
    }

    // Verify ownership
    if (listing.host.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      return res.status(403).json({ success: false, message: 'Not authorized to update this listing' });
    }

    listing = await Listing.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    });

    res.json({
      success: true,
      message: 'Listing updated successfully',
      listing,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Delete listing
// @route   DELETE /api/listings/:id
// @access  Private (Owner/Admin)
const deleteListing = async (req, res) => {
  try {
    const listing = await Listing.findById(req.params.id);

    if (!listing) {
      return res.status(404).json({ success: false, message: 'Listing not found' });
    }

    if (listing.host.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      return res.status(403).json({ success: false, message: 'Not authorized to delete this listing' });
    }

    await Listing.findByIdAndDelete(req.params.id);

    res.json({
      success: true,
      message: 'Listing removed successfully',
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get listings created by authenticated host
// @route   GET /api/listings/host/my-listings
// @access  Private
const getHostListings = async (req, res) => {
  try {
    const listings = await Listing.find({ host: req.user._id }).sort({ createdAt: -1 });

    res.json({
      success: true,
      count: listings.length,
      listings,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Upload listing photos via Multer
// @route   POST /api/listings/upload
// @access  Private
const uploadListingImages = async (req, res) => {
  try {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({ success: false, message: 'No images uploaded' });
    }

    const host = req.get('host');
    const protocol = req.protocol;
    const imageUrls = req.files.map((file) => `${protocol}://${host}/uploads/${file.filename}`);

    res.json({
      success: true,
      images: imageUrls,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

module.exports = {
  getAllListings,
  getListingById,
  createListing,
  updateListing,
  deleteListing,
  getHostListings,
  uploadListingImages,
};
