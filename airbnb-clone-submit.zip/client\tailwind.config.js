/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        airbnb: {
          light: '#FF5A5F',
          DEFAULT: '#FF385C',
          dark: '#E00B41',
          black: '#222222',
          gray: '#717171',
          lightgray: '#F7F7F7',
          border: '#DDDDDD',
        }
      },
      fontFamily: {
        sans: ['Circular', '-apple-system', 'BlinkMacSystemFont', 'Roboto', 'Helvetica Neue', 'sans-serif'],
      },
      boxShadow: {
        'airbnb': '0 3px 12px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.08)',
        'airbnb-hover': '0 6px 20px rgba(0,0,0,0.15)',
        'card': '0 6px 16px rgba(0, 0, 0, 0.08)',
      }
    },
  },
  plugins: [],
}
