const Booking = require('../models/Booking');
const Listing = require('../models/Listing');

// @desc    Create a new reservation / booking
// @route   POST /api/bookings
// @access  Private
const createBooking = async (req, res) => {
  try {
    const {
      listingId,
      checkIn,
      checkOut,
      guests = { adults: 1, children: 0, infants: 0 },
      specialRequests,
    } = req.body;

    if (!listingId || !checkIn || !checkOut) {
      return res.status(400).json({
        success: false,
        message: 'Please provide listing ID, check-in date, and check-out date',
      });
    }

    const start = new Date(checkIn);
    const end = new Date(checkOut);

    if (start >= end) {
      return res.status(400).json({
        success: false,
        message: 'Check-out date must be after check-in date',
      });
    }

    // Verify property exists
    const listing = await Listing.findById(listingId);
    if (!listing) {
      return res.status(404).json({ success: false, message: 'Property listing not found' });
    }

    // Check maximum guests
    const totalGuests = (guests.adults || 1) + (guests.children || 0);
    if (totalGuests > listing.maxGuests) {
      return res.status(400).json({
        success: false,
        message: `This property allows a maximum of ${listing.maxGuests} guests`,
      });
    }

    // Prevent host from booking their own property
    if (listing.host.toString() === req.user._id.toString()) {
      return res.status(400).json({
        success: false,
        message: 'You cannot book your own listing',
      });
    }

    // Check for date clashes with existing active bookings
    const overlappingBooking = await Booking.findOne({
      listing: listingId,
      status: { $ne: 'cancelled' },
      $or: [
        {
          checkIn: { $lt: end },
          checkOut: { $gt: start },
        },
      ],
    });

    if (overlappingBooking) {
      return res.status(400).json({
        success: false,
        message: 'These dates are already reserved for this property. Please pick another date range.',
      });
    }

    // Calculate nights and price
    const diffTime = Math.abs(end.getTime() - start.getTime());
    const nights = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) || 1;
    const basePrice = nights * listing.pricePerNight;
    const cleaningFee = listing.cleaningFee || 0;
    const serviceFee = listing.serviceFee || Math.round(basePrice * 0.12);
    const totalPrice = basePrice + cleaningFee + serviceFee;

    const booking = await Booking.create({
      listing: listing._id,
      user: req.user._id,
      host: listing.host,
      checkIn: start,
      checkOut: end,
      guests,
      totalGuests,
      nights,
      pricePerNight: listing.pricePerNight,
      cleaningFee,
      serviceFee,
      totalPrice,
      status: 'confirmed',
      paymentStatus: 'paid',
      specialRequests: specialRequests || '',
    });

    const populatedBooking = await Booking.findById(booking._id)
      .populate('listing')
      .populate('host', 'name email avatar');

    res.status(201).json({
      success: true,
      message: 'Reservation confirmed successfully!',
      booking: populatedBooking,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get logged in user's bookings (trips)
// @route   GET /api/bookings/my-bookings
// @access  Private
const getUserBookings = async (req, res) => {
  try {
    const bookings = await Booking.find({ user: req.user._id })
      .populate({
        path: 'listing',
        select: 'title images location pricePerNight propertyType',
      })
      .populate('host', 'name email avatar')
      .sort({ createdAt: -1 });

    res.json({
      success: true,
      count: bookings.length,
      bookings,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get reservations for properties hosted by user
// @route   GET /api/bookings/host-reservations
// @access  Private
const getHostBookings = async (req, res) => {
  try {
    const bookings = await Booking.find({ host: req.user._id })
      .populate({
        path: 'listing',
        select: 'title images location pricePerNight',
      })
      .populate('user', 'name email avatar')
      .sort({ createdAt: -1 });

    res.json({
      success: true,
      count: bookings.length,
      bookings,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get all booked date ranges for a listing (for calendar disabling)
// @route   GET /api/bookings/listing/:listingId/dates
// @access  Public
const getListingBookedDates = async (req, res) => {
  try {
    const bookings = await Booking.find({
      listing: req.params.listingId,
      status: { $ne: 'cancelled' },
    }).select('checkIn checkOut');

    res.json({
      success: true,
      bookedDates: bookings,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get booking details by ID
// @route   GET /api/bookings/:id
// @access  Private
const getBookingById = async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.id)
      .populate('listing')
      .populate('user', 'name email avatar phone')
      .populate('host', 'name email avatar phone');

    if (!booking) {
      return res.status(404).json({ success: false, message: 'Booking not found' });
    }

    // Verify authorized user (guest or host or admin)
    const isGuest = booking.user._id.toString() === req.user._id.toString();
    const isHost = booking.host._id.toString() === req.user._id.toString();

    if (!isGuest && !isHost && req.user.role !== 'admin') {
      return res.status(403).json({ success: false, message: 'Not authorized to view this booking' });
    }

    res.json({
      success: true,
      booking,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Cancel a booking
// @route   PUT /api/bookings/:id/cancel
// @access  Private
const cancelBooking = async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.id);

    if (!booking) {
      return res.status(404).json({ success: false, message: 'Booking not found' });
    }

    const isGuest = booking.user.toString() === req.user._id.toString();
    const isHost = booking.host.toString() === req.user._id.toString();

    if (!isGuest && !isHost && req.user.role !== 'admin') {
      return res.status(403).json({ success: false, message: 'Not authorized to cancel this booking' });
    }

    booking.status = 'cancelled';
    booking.paymentStatus = 'refunded';
    await booking.save();

    res.json({
      success: true,
      message: 'Booking cancelled successfully',
      booking,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

module.exports = {
  createBooking,
  getUserBookings,
  getHostBookings,
  getListingBookedDates,
  getBookingById,
  cancelBooking,
};
