import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Star, Heart, ChevronLeft, ChevronRight } from 'lucide-react';

const ListingCard = ({ listing }) => {
  const navigate = useNavigate();
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [isFavorite, setIsFavorite] = useState(false);

  const images = listing.images && listing.images.length > 0
    ? listing.images
    : ['https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=1200&q=80'];

  const handleNextImage = (e) => {
    e.stopPropagation();
    setCurrentImageIndex((prev) => (prev + 1) % images.length);
  };

  const handlePrevImage = (e) => {
    e.stopPropagation();
    setCurrentImageIndex((prev) => (prev - 1 + images.length) % images.length);
  };

  const toggleFavorite = (e) => {
    e.stopPropagation();
    setIsFavorite(!isFavorite);
  };

  return (
    <div
      onClick={() => navigate(`/listings/${listing._id}`)}
      className="group cursor-pointer flex flex-col space-y-2.5 transition transform hover:-translate-y-1 duration-200"
    >
      {/* Image Container with Carousel & Favorite */}
      <div className="relative aspect-square w-full overflow-hidden rounded-2xl bg-gray-100 shadow-xs">
        <img
          src={images[currentImageIndex]}
          alt={listing.title}
          className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
          loading="lazy"
        />

        {/* Favorite Heart Button */}
        <button
          onClick={toggleFavorite}
          className="absolute top-3 right-3 p-1.5 rounded-full hover:scale-110 active:scale-95 transition z-10"
        >
          <Heart
            className={`w-6 h-6 stroke-[2] drop-shadow-md ${
              isFavorite
                ? 'fill-airbnb text-airbnb'
                : 'fill-black/30 text-white hover:fill-black/50'
            }`}
          />
        </button>

        {/* Carousel Navigation Arrows (shown if > 1 image) */}
        {images.length > 1 && (
          <>
            <button
              onClick={handlePrevImage}
              className="absolute left-2.5 top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white text-gray-800 p-1.5 rounded-full shadow-md opacity-0 group-hover:opacity-100 transition duration-150 z-10"
            >
              <ChevronLeft className="w-4 h-4 stroke-[2.5]" />
            </button>
            <button
              onClick={handleNextImage}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white text-gray-800 p-1.5 rounded-full shadow-md opacity-0 group-hover:opacity-100 transition duration-150 z-10"
            >
              <ChevronRight className="w-4 h-4 stroke-[2.5]" />
            </button>

            {/* Pagination Dots */}
            <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex space-x-1.5 z-10">
              {images.slice(0, 5).map((_, idx) => (
                <div
                  key={idx}
                  className={`h-1.5 rounded-full transition-all ${
                    idx === currentImageIndex
                      ? 'w-4 bg-white'
                      : 'w-1.5 bg-white/60'
                  }`}
                />
              ))}
            </div>
          </>
        )}

        {/* Featured Tag */}
        {listing.isFeatured && (
          <div className="absolute top-3 left-3 bg-white/90 backdrop-blur-xs text-gray-900 text-[11px] font-bold px-2.5 py-1 rounded-full shadow-xs">
            Guest favorite
          </div>
        )}
      </div>

      {/* Listing Information */}
      <div className="flex flex-col text-sm">
        <div className="flex items-center justify-between font-semibold text-gray-900">
          <span className="truncate pr-2">
            {listing.location?.city}, {listing.location?.country}
          </span>
          <div className="flex items-center space-x-1 flex-shrink-0">
            <Star className="w-3.5 h-3.5 fill-current text-gray-900" />
            <span>{listing.rating ? listing.rating.toFixed(2) : 'New'}</span>
          </div>
        </div>

        <p className="text-gray-500 text-xs truncate capitalize">
          {listing.propertyType} • {listing.category}
        </p>

        <p className="text-gray-500 text-xs truncate">
          {listing.maxGuests} guests • {listing.bedrooms} bed{listing.bedrooms > 1 ? 's' : ''}
        </p>

        <div className="pt-1 flex items-baseline space-x-1 text-gray-900">
          <span className="font-bold text-base">${listing.pricePerNight}</span>
          <span className="text-xs text-gray-600 font-normal">night</span>
        </div>
      </div>
    </div>
  );
};

export default ListingCard;
