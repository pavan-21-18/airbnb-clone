import React, { useState, useRef, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Search, Globe, Menu, User as UserIcon, Home, Compass, Calendar, LogOut, PlusCircle } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const Navbar = ({ onOpenSearch }) => {
  const { user, isAuthenticated, logout, openAuthModal } = useAuth();
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef(null);
  const navigate = useNavigate();

  // Close dropdown menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (menuRef.current && !menuRef.current.contains(e.target)) {
        setMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleHostClick = () => {
    if (!isAuthenticated) {
      openAuthModal('login');
    } else {
      navigate('/create-listing');
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-gray-200 transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Left: Brand Logo */}
          <Link to="/" className="flex items-center space-x-2 flex-shrink-0">
            <svg
              className="w-9 h-9 text-airbnb fill-current"
              viewBox="0 0 32 32"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path d="M16 1c2.008 0 3.463.963 4.751 3.269l.533 1.025c1.954 3.83 6.114 12.54 7.1 14.836l.145.353c.667 1.591.91 2.472.96 3.396l.011.314c0 4.29-3.262 7.807-7.469 7.807-2.73 0-5.088-1.464-6.031-3.642-1.008 2.178-3.301 3.642-6.031 3.642-4.207 0-7.469-3.517-7.469-7.807 0-1.127.288-2.227.971-3.71l.145-.353c.986-2.296 5.146-11.006 7.1-14.836l.533-1.025C9.537 1.963 10.992 1 13 1h3zm0 2.2c-1.314 0-2.317.653-3.328 2.502l-.472.915c-1.895 3.712-6.012 12.333-6.974 14.593-.574 1.25-.826 2.13-.826 3.09 0 3.09 2.274 5.607 5.269 5.607 2.378 0 4.394-1.637 4.963-3.925l.128-.591h2.479l.129.591c.568 2.288 2.584 3.925 4.962 3.925 2.995 0 5.269-2.517 5.269-5.607 0-.96-.252-1.84-.826-3.09-.962-2.26-5.079-10.881-6.974-14.593l-.472-.915C20.317 3.853 19.314 3.2 18 3.2h-2zm0 13.8a3.5 3.5 0 110 7 3.5 3.5 0 010-7zm0 2.2a1.3 1.3 0 100 2.6 1.3 1.3 0 000-2.6z" />
            </svg>
            <span className="font-bold text-xl tracking-tight text-airbnb hidden sm:inline-block">
              airbnb
            </span>
          </Link>

          {/* Center: Search Pill Trigger */}
          <button
            onClick={onOpenSearch}
            className="flex items-center border border-gray-300 rounded-full py-2 px-4 shadow-sm hover:shadow-md transition text-sm font-medium divide-x divide-gray-200"
          >
            <span className="pr-3 text-gray-800 font-semibold">Anywhere</span>
            <span className="px-3 text-gray-800 font-semibold hidden md:inline">Any week</span>
            <span className="pl-3 text-gray-500 flex items-center space-x-2">
              <span className="hidden sm:inline">Add guests</span>
              <div className="bg-airbnb text-white p-2 rounded-full ml-1">
                <Search className="w-3.5 h-3.5 stroke-[2.5]" />
              </div>
            </span>
          </button>

          {/* Right: Host button & User dropdown */}
          <div className="flex items-center space-x-2">
            <button
              onClick={handleHostClick}
              className="text-sm font-semibold text-gray-700 hover:bg-gray-100 py-2 px-3.5 rounded-full transition hidden md:block"
            >
              Airbnb your home
            </button>

            <button
              aria-label="Language & currency"
              className="p-2.5 rounded-full hover:bg-gray-100 transition text-gray-700 hidden sm:block"
            >
              <Globe className="w-4 h-4" />
            </button>

            {/* User Profile Pill Menu */}
            <div className="relative" ref={menuRef}>
              <button
                onClick={() => setMenuOpen(!menuOpen)}
                className="flex items-center space-x-3 border border-gray-300 rounded-full py-1.5 px-3 hover:shadow-md transition focus:outline-none"
              >
                <Menu className="w-4 h-4 text-gray-600" />
                {isAuthenticated && user?.avatar ? (
                  <img
                    src={user.avatar}
                    alt={user.name}
                    className="w-7 h-7 rounded-full object-cover border border-gray-200"
                  />
                ) : (
                  <div className="w-7 h-7 bg-gray-500 rounded-full flex items-center justify-center text-white">
                    <UserIcon className="w-4 h-4" />
                  </div>
                )}
              </button>

              {/* Dropdown Menu Modal */}
              {menuOpen && (
                <div className="absolute right-0 mt-2 w-64 bg-white rounded-2xl shadow-xl border border-gray-100 py-2 z-50 text-sm animate-in fade-in slide-in-from-top-2 duration-150">
                  {isAuthenticated ? (
                    <>
                      <div className="px-4 py-2 border-b border-gray-100 mb-1">
                        <p className="font-semibold text-gray-900 truncate">{user?.name}</p>
                        <p className="text-xs text-gray-500 truncate">{user?.email}</p>
                        <span className="inline-block mt-1 text-[10px] font-semibold tracking-wider uppercase px-2 py-0.5 rounded-full bg-rose-50 text-airbnb">
                          {user?.role === 'admin' ? 'Administrator' : user?.role === 'host' ? 'Superhost' : 'Guest'}
                        </span>
                      </div>

                      <Link
                        to="/dashboard?tab=trips"
                        onClick={() => setMenuOpen(false)}
                        className="flex items-center space-x-3 px-4 py-2.5 hover:bg-gray-50 text-gray-700 transition"
                      >
                        <Calendar className="w-4 h-4 text-gray-500" />
                        <span>My Trips & Bookings</span>
                      </Link>

                      <Link
                        to="/dashboard?tab=listings"
                        onClick={() => setMenuOpen(false)}
                        className="flex items-center space-x-3 px-4 py-2.5 hover:bg-gray-50 text-gray-700 transition"
                      >
                        <Home className="w-4 h-4 text-gray-500" />
                        <span>Manage Listings</span>
                      </Link>

                      <Link
                        to="/dashboard?tab=reservations"
                        onClick={() => setMenuOpen(false)}
                        className="flex items-center space-x-3 px-4 py-2.5 hover:bg-gray-50 text-gray-700 transition"
                      >
                        <Compass className="w-4 h-4 text-gray-500" />
                        <span>Host Reservations</span>
                      </Link>

                      <Link
                        to="/create-listing"
                        onClick={() => setMenuOpen(false)}
                        className="flex items-center space-x-3 px-4 py-2.5 hover:bg-gray-50 text-airbnb font-medium transition"
                      >
                        <PlusCircle className="w-4 h-4 text-airbnb" />
                        <span>Create new listing</span>
                      </Link>

                      <div className="border-t border-gray-100 my-1"></div>

                      <Link
                        to="/dashboard?tab=profile"
                        onClick={() => setMenuOpen(false)}
                        className="flex items-center space-x-3 px-4 py-2.5 hover:bg-gray-50 text-gray-700 transition"
                      >
                        <UserIcon className="w-4 h-4 text-gray-500" />
                        <span>Account Profile</span>
                      </Link>

                      <button
                        onClick={() => {
                          logout();
                          setMenuOpen(false);
                        }}
                        className="w-full flex items-center space-x-3 px-4 py-2.5 hover:bg-rose-50 text-rose-600 transition text-left font-medium"
                      >
                        <LogOut className="w-4 h-4" />
                        <span>Log out</span>
                      </button>
                    </>
                  ) : (
                    <>
                      <button
                        onClick={() => {
                          openAuthModal('login');
                          setMenuOpen(false);
                        }}
                        className="w-full text-left px-4 py-2.5 font-semibold text-gray-900 hover:bg-gray-50 transition"
                      >
                        Log in
                      </button>
                      <button
                        onClick={() => {
                          openAuthModal('register');
                          setMenuOpen(false);
                        }}
                        className="w-full text-left px-4 py-2.5 text-gray-600 hover:bg-gray-50 transition"
                      >
                        Sign up
                      </button>

                      <div className="border-t border-gray-100 my-1"></div>

                      <button
                        onClick={() => {
                          openAuthModal('login');
                          setMenuOpen(false);
                        }}
                        className="w-full text-left px-4 py-2.5 text-gray-700 hover:bg-gray-50 transition"
                      >
                        Airbnb your home
                      </button>
                      <a
                        href="#help"
                        onClick={(e) => {
                          e.preventDefault();
                          alert('Airbnb Clone Capstone Project - Module 8 MERN Stack');
                          setMenuOpen(false);
                        }}
                        className="block px-4 py-2.5 text-gray-700 hover:bg-gray-50 transition"
                      >
                        Help Center
                      </a>
                    </>
                  )}
                </div>
              )}
            </div>
          </div>

        </div>
      </div>
    </header>
  );
};

export default Navbar;
