import React, { createContext, useContext, useState, useEffect } from 'react';
import { authApi } from '../api/authApi';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(() => {
    const savedUser = localStorage.getItem('airbnb_user');
    return savedUser ? JSON.parse(savedUser) : null;
  });
  const [token, setToken] = useState(() => localStorage.getItem('airbnb_token') || null);
  const [loading, setLoading] = useState(true);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalMode, setAuthModalMode] = useState('login'); // 'login' | 'register'

  useEffect(() => {
    const verifyToken = async () => {
      if (token) {
        try {
          const data = await authApi.getProfile();
          if (data.success && data.user) {
            setUser(data.user);
            localStorage.setItem('airbnb_user', JSON.stringify(data.user));
          }
        } catch (err) {
          console.warn('Session expired or invalid token:', err.message);
          logout();
        }
      }
      setLoading(false);
    };

    verifyToken();
  }, [token]);

  const login = async (email, password) => {
    try {
      const data = await authApi.login({ email, password });
      if (data.success) {
        setUser(data.user);
        setToken(data.token);
        localStorage.setItem('airbnb_token', data.token);
        localStorage.setItem('airbnb_user', JSON.stringify(data.user));
        setIsAuthModalOpen(false);
        return { success: true };
      }
    } catch (error) {
      return {
        success: false,
        message: error.response?.data?.message || 'Login failed. Please check your credentials.',
      };
    }
  };

  const register = async (userData) => {
    try {
      const data = await authApi.register(userData);
      if (data.success) {
        setUser(data.user);
        setToken(data.token);
        localStorage.setItem('airbnb_token', data.token);
        localStorage.setItem('airbnb_user', JSON.stringify(data.user));
        setIsAuthModalOpen(false);
        return { success: true };
      }
    } catch (error) {
      return {
        success: false,
        message: error.response?.data?.message || 'Registration failed.',
      };
    }
  };

  const logout = () => {
    setUser(null);
    setToken(null);
    localStorage.removeItem('airbnb_token');
    localStorage.removeItem('airbnb_user');
  };

  const updateProfile = async (profileData) => {
    try {
      const data = await authApi.updateProfile(profileData);
      if (data.success) {
        setUser(data.user);
        localStorage.setItem('airbnb_user', JSON.stringify(data.user));
        return { success: true };
      }
    } catch (error) {
      return {
        success: false,
        message: error.response?.data?.message || 'Profile update failed.',
      };
    }
  };

  const openAuthModal = (mode = 'login') => {
    setAuthModalMode(mode);
    setIsAuthModalOpen(true);
  };

  const closeAuthModal = () => {
    setIsAuthModalOpen(false);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        loading,
        isAuthenticated: !!user,
        isAuthModalOpen,
        authModalMode,
        login,
        register,
        logout,
        updateProfile,
        openAuthModal,
        closeAuthModal,
        setAuthModalMode,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
